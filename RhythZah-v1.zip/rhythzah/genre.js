'use strict';
/* 曲風 → 歌詞風格(v19)
 * 支援英文 / 繁中 / 簡中 / 日文 / 韓文的曲風名稱(iTunes 各國商店會回各國語言的曲風名)。
 * 十三種風格:pop idol hiphop rock rnb edm jazz folk dream latin  +  ballad retro cine(v19 新增) */
const RULES = [
  ['hiphop', /hip.?hop|\brap\b|trap|drill|grime|嘻哈|說唱|说唱|饒舌|ヒップホップ|ラップ|힙합|랩/i],
  ['rock', /metal|punk|rock|alternative|grunge|hardcore|emo\b|post.?hardcore|搖滾|摇滚|龐克|朋克|金屬|金属|ロック|パンク|록|메탈/i],
  ['rnb', /r&b|r&amp;b|r ?& ?b|soul|funk|motown|neo.?soul|節奏藍調|节奏布鲁斯|靈魂|灵魂|ソウル|알앤비|소울|ファンク/i],
  ['edm', /electronic|dance(?!hall)|house|techno|edm|trance|dubstep|club|drum|bass\b|electro|電子|电子|舞曲|電音|电音|テクノ|ハウス|エレクトロ|ダンス|일렉|댄스/i],
  ['retro', /city ?pop|disco|synth.?pop|new wave|synthwave|vaporwave|retro|80s|70s|シティポップ|ディスコ|復古|复古|迪斯可|昭和/i],
  ['cine', /soundtrack|score|film|\bost\b|orchestral|cinematic|classical|opera|symphon|原聲|原声|電影|电影|配樂|配乐|サウンドトラック|クラシック|古典|오케스트라|사운드트랙/i],
  ['jazz', /jazz|blues|swing|standards|bossa|lounge|vocal|big band|爵士|藍調|蓝调|ジャズ|ブルース|재즈/i],
  ['ballad', /ballad|lullaby|torch|抒情|慢歌|情歌|バラード|발라드/i],
  ['folk', /country|folk|bluegrass|americana|singer.?songwriter|acoustic|songwriter|民謠|民谣|鄉村|乡村|フォーク|カントリー|포크|어쿠스틱|싱어송라이터/i],
  ['dream', /ambient|new age|chill|lo-?fi|easy listening|relax|meditation|indie|dream|shoegaze|sleep|healing|氛圍|氛围|新世紀|新世纪|輕音樂|轻音乐|療癒|疗愈|ヒーリング|アンビエント|獨立|独立|インディ|인디/i],
  ['latin', /latin|reggae|reggaeton|salsa|afro|dancehall|caribbean|tropical|world|samba|bachata|cumbia|flamenco|拉丁|雷鬼|世界音樂|世界音乐|ラテン|レゲエ|라틴/i],
  ['idol', /k-?pop|j-?pop|anime|idol|kayokyoku|vocaloid|enka|日本流行|韓國流行|韩国流行|ジェイポップ|アニメ|動漫|动漫|偶像|アイドル|케이팝|가요|歌謠|歌谣|演歌|ボーカロイド|j-?rock/i],
  ['pop', /pop|mandopop|cantopop|c-?pop|taiwan|mando|國語|国语|華語|华语|粵語|粤语|台語|流行|ポップ|팝/i],
];
function themeOf(g) {
  const s = String(g || '');
  for (const [th, re] of RULES) if (re.test(s)) return th;
  return s ? 'pop' : null;
}
// 從歌名看得出來的線索(混音版、原聲帶、慢速版…)
function titleHint(title) {
  const t = String(title || '');
  if (/nightcore|sped.?up|hardstyle|club mix|extended mix|\bremix\b|\bedit\b/i.test(t)) return 'edm';
  if (/slowed|reverb|lo-?fi|chill|sleep|ambient/i.test(t)) return 'dream';
  if (/acoustic|unplugged|不插電|アコースティック/i.test(t)) return 'folk';
  if (/piano|鋼琴|钢琴|ピアノ|ballad|抒情|慢歌/i.test(t)) return 'ballad';
  if (/\bost\b|theme song|主題曲|主题曲|片尾曲|片頭曲|插曲|原聲|main theme|soundtrack/i.test(t)) return 'cine';
  if (/city ?pop|disco|synthwave|80s|復古/i.test(t)) return 'retro';
  if (/\bfeat\b.*\brap|\brap\b|cypher|freestyle|說唱|饒舌/i.test(t)) return 'hiphop';
  return null;
}
/* votes: [{ g:'Mandopop', w:1 }, ...]  → { theme, genre }。具體的風格贏過泛稱的 pop。 */
function decide(votes, title) {
  const sc = {}, name = {};
  votes.forEach(v => { const th = themeOf(v.g); if (!th) return; sc[th] = (sc[th] || 0) + v.w; if (!name[th]) name[th] = v.g; });
  const hint = titleHint(title); if (hint) { sc[hint] = (sc[hint] || 0) + .7; name[hint] = name[hint] || ''; }
  const ents = Object.entries(sc); if (!ents.length) return { theme: null, genre: '' };
  const pop = sc.pop || 0, spec = ents.filter(([k]) => k !== 'pop').sort((a, b) => b[1] - a[1])[0];
  const th = (spec && spec[1] * 2 >= pop) ? spec[0] : 'pop';
  const genre = name[th] || (votes.find(v => themeOf(v.g) === th) || {}).g || '';
  return { theme: th, genre };
}
module.exports = { themeOf, titleHint, decide };
