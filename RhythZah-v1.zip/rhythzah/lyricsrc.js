'use strict';
/* 多來源同步歌詞抓取(v19)
 * 來源:LRCLIB、網易雲、酷狗、QQ 音樂(都不用金鑰)。
 * 流程:各來源同時搜尋 → 依「歌名/歌手/長度」評分 → 載入最像的幾個 → 解析(含逐字時間、版權行過濾)→ 挑最好的。
 * 最後的退路:只有純文字歌詞時,依歌曲長度估時間(標記為 est)。結果會存到硬碟,下次秒開。 */
const fs = require('fs');

// ---------- 簡繁轉換(只收常見字;[繁, 簡]) ----------
const PAIRS = ('愛爱 邊边 變变 別别 並并 補补 場场 車车 陳陈 稱称 誠诚 遲迟 蟲虫 處处 傳传 創创 從从 帶带 單单 當当 黨党 導导 燈灯 點点 電电 調调 動动 斷断 對对 兒儿 發发 範范 飛飞 風风 復复 該该 剛刚 個个 給给 過过 國国 話话 華华 壞坏 歡欢 還还 環环 換换 會会 幾几 機机 記记 際际 繼继 價价 間间 見见 將将 腳脚 較较 節节 結结 緊紧 進进 經经 驚惊 舊旧 開开 課课 禮礼 離离 裡里 歷历 聯联 戀恋 兩两 臉脸 練练 鄰邻 樓楼 淚泪 麗丽 輛辆 靈灵 領领 龍龙 論论 媽妈 嗎吗 買买 賣卖 滿满 夢梦 麼么 們们 難难 憑凭 氣气 親亲 輕轻 請请 區区 勸劝 確确 讓让 熱热 認认 滅灭 傷伤 設设 聲声 師师 時时 識识 實实 屬属 說说 書书 雖虽 隨随 歲岁 孫孙 態态 臺台 嘆叹 體体 條条 聽听 頭头 圖图 團团 為为 衛卫 問问 無无 習习 戲戏 現现 線线 鄉乡 響响 學学 尋寻 壓压 豔艳 陽阳 樣样 藥药 遙遥 業业 億亿 憶忆 應应 與与 語语 預预 願愿 員员 雲云 運运 這这 鎮镇 爭争 證证 織织 質质 終终 週周 專专 轉转 莊庄 準准 總总 縱纵 組组 後后 寶宝 報报 筆笔 閉闭 畢毕 辦办 標标 賓宾 參参 層层 產产 長长 償偿 廠厂 徹彻 塵尘 籌筹 觸触 辭辞 達达 擔担 彈弹 膽胆 誕诞 憂忧 敵敌 遞递 訂订 鬥斗 獨独 讀读 惡恶 婦妇 負负 溝沟 廣广 歸归 貴贵 滾滚 號号 兇凶 憐怜 憤愤 揮挥 懷怀 擁拥 擇择 擾扰 攜携 敘叙 數数 斬斩 時时 曆历 檔档 櫃柜 歲岁 殘残 殺杀 氫氢 淺浅 滄沧 灣湾 煙烟 狀状 獎奖 獲获 瑪玛 瓊琼 畫画 疊叠 療疗 癡痴 盡尽 監监 矚瞩 礎础 禍祸 竅窍 築筑 簡简 糾纠 紅红 純纯 紙纸 紛纷 細细 紫紫 絕绝 絲丝 綁绑 綠绿 維维 綿绵 網网 緣缘 縫缝 縮缩 繞绕 繪绘 續续 纏缠 罵骂 羅罗 義义 習习 翹翘 聖圣 聞闻 職职 脅胁 艦舰 艱艰 蘭兰 處处 衝冲 補补 裝装 襲袭 視视 覺觉 觀观 訊讯 許许 訝讶 訴诉 詞词 詩诗 詢询 該该 詳详 誤误 誰谁 課课 謊谎 謝谢 謠谣 謎谜 譜谱 護护 變变 豐丰 貓猫 貝贝 貞贞 負负 財财 責责 貨货 販贩 貪贪 貧贫 貼贴 賞赏 賭赌 賴赖 趕赶 趨趋 跡迹 躍跃 軀躯 輝辉 輩辈 輪轮 轟轰 辯辩 迴回 遊游 運运 遠远 適适 遲迟 選选 邁迈 郵邮 鄭郑 醜丑 醫医 釋释 鐘钟 鐵铁 鑰钥 鑽钻 針针 鈴铃 銀银 錄录 錯错 鍵键 鎖锁 鏡镜 鐺铛 門门 閃闪 閒闲 閣阁 闖闯 闊阔 闆板 隊队 陰阴 陸陆 險险 隱隐 雙双 雜杂 雞鸡 離离 難难 顏颜 願愿 顧顾 顯显 飄飘 餘余 館馆 饑饥 驗验 驚惊 骯脏 鬆松 魚鱼 鳥鸟 鳴鸣 鴻鸿 鷹鹰 鹽盐 麗丽 黃黄 點点 齊齐 齡龄 龜龟 來来 樂乐 沒没 戰战 試试 寫写 馬马 東东 關关 張张 藍蓝 營营 眾众 蘇苏 勞劳 務务 勝胜 協协 嚴严 喚唤 嘗尝 圓圆 園园 圍围 執执 堅坚 壯壮 備备 優优 偉伟 傘伞 儘尽 內内 冊册 剎刹 劇剧 勵励 卻却 厭厌 叢丛 嚇吓 囑嘱 壇坛 奪夺 奮奋 妝妆 寧宁 寵宠 屆届 島岛 嶼屿 帥帅 幣币 幫帮 廳厅 彎弯 徵征 懸悬 戶户 拋抛 擊击 擋挡 據据 擠挤 敗败 於于 暫暂 曬晒 橫横 櫻樱 毀毁 溫温 漢汉 漸渐 潔洁 濃浓 濕湿 燒烧 爺爷 牆墙 猶犹 獸兽 異异 瘋疯 盜盗 盤盘 睜睁 碼码 窮穷 簽签 籠笼 粵粤 糧粮 聰聪 腦脑 臨临 興兴 舉举 藝艺 計计 討讨 訪访 評评 誇夸 諾诺 豈岂 費费 賀贺 賽赛 贈赠 贏赢 軟软 錢钱 閱阅 隻只 靜静 韓韩 頁页 頂顶 順顺 題题 額额 顆颗 類类 飯饭 餓饿 鬧闹 鮮鲜 麥麦 倉仓 吳吴 萬万 與与 專专 喪丧 臨临 舉举 義义 烏乌 亂乱 虧亏 亞亚 僅仅 儀仪 倫伦 偽伪 俠侠 侶侣 偵侦 側侧 僑侨 倆俩 儉俭 債债 傾倾 儲储 兌兑 養养 岡冈 軍军 農农 馮冯 決决 況况 凍冻 淨净 涼凉 減减 鳳凤 凱凯 劃划 劉刘 則则 刪删 劍剑 勁劲 勢势 勛勋 盧卢 廁厕 廚厨 縣县 啟启 詠咏 啞哑 嘩哗 嘯啸 噴喷 噓嘘 塊块 壩坝 墳坟 墜坠 壟垄 壘垒 殼壳 夠够 夾夹 奧奥 嫵妩 姍姗 娛娱 嬌娇 審审 憲宪 宮宫 寬宽 爾尔 屜屉 嶺岭 嶽岳 峽峡 巒峦 巔巅 帳帐 簾帘 慶庆 庫库 廟庙 龐庞 廢废 棄弃 彌弥 強强 徑径 懷怀 惱恼 慘惨 慣惯 懾慑 撲扑 掃扫 揚扬 撫抚 搶抢 擬拟 攔拦 掛挂 摯挚 撈捞 損损 撿捡 擲掷 攬揽 攙搀 攝摄 擺摆 搖摇 攤摊 撐撑 攢攒 齋斋 曠旷 曇昙 曉晓 暈晕 暉晖 曖暧 術术 樸朴 權权 楊杨 極极 構构 槍枪 欄栏 樹树 橋桥 檢检 橢椭 檻槛 歐欧 殲歼 斃毙 湯汤 灑洒 漿浆 澆浇 濁浊 測测 濟济 塗涂 濤涛 澇涝 漲涨 潤润 湧涌 澱淀 漁渔 滲渗 潰溃 濱滨 灘滩 濫滥 濾滤 災灾 燦灿 爐炉 煉炼 爛烂 煩烦 燙烫 煥焕 牽牵 犧牺 獅狮 獄狱 獵猎 豬猪 獻献 瑣琐 瑤瑶 蓋盖 矯矫 礦矿 磚砖 碩硕 礙碍 種种 積积 穎颖 竊窃 窩窝 競竞 箋笺 篩筛 簫箫 籃篮 紀纪 約约 級级 紗纱 綱纲 納纳 紋纹 紹绍 絨绒 絡络 統统 繼继 績绩 緒绪 綺绮 緋绯 繩绳 綜综 綻绽 綴缀 緬缅 纜缆 緩缓 縷缕 編编 縛缚 繳缴 罰罚 罷罢 聳耸 恥耻 聶聂 腸肠 腫肿 脹胀 脈脉 臘腊 膩腻 艙舱 蘆芦 蒼苍 繭茧 蕩荡 榮荣 萊莱 蓮莲 瑩莹 蕭萧 薔蔷 慮虑 虛虚 蟻蚁 蠻蛮 襯衬 褲裤 規规 覽览 覓觅 譽誉 講讲 諷讽 訣诀 診诊 譯译 誦诵 諸诸 談谈 誼谊 謂谓 謙谦 賢贤 貫贯 貸贷 貿贸 賊贼 賦赋 賜赐 賠赔 賺赚 贊赞 踐践 軌轨 軒轩 轎轿 輔辅 輯辑 輸输 違违 連连 遜逊 醬酱 釀酿 鉛铅 銅铜 銘铭 鋪铺 鏈链 銷销 鋒锋 銳锐 錦锦 悶闷 陣阵 階阶 霧雾 韻韵 頓顿 頹颓 顛颠 顫颤 飾饰 飽饱 駕驾 騎骑 騙骗 鶴鹤 齒齿 馳驰 髮发 裏里 壇坛 鷗鸥 鯨鲸 鷺鹭 鳳凤 鴨鸭 鵝鹅 鴛鸳 鸞鸾 魯鲁 鮮鲜 駁驳 驢驴 驛驿 驟骤 騷骚 驅驱 髏髅 鬢鬓 魘魇 麼么 儘尽 壺壶 懲惩 戰战 戲戏 擴扩 攪搅 敵敌 斬斩 暢畅 栗栗 橫横 歡欢 殘残 氣气 淵渊 湊凑 滅灭 漬渍 瀰弥 灣湾 熒荧 燭烛 爍烁 牆墙 犢犊 狀状 猶犹 獲获 琺珐 瓏珑 畝亩 痙痉 瘡疮 癥症 皚皑 盞盏 睏困 矚瞩 礫砾 禪禅 稟禀 穫获 窪洼 窯窑 竄窜 筍笋 築筑 篤笃 簍篓 糴籴 絆绊 綁绑 縱纵 繽缤 纏缠 缽钵 羈羁 翹翘 耬耧 聾聋 脅胁 臟脏 艦舰 艱艰 芻刍 莖茎 菸烟 葉叶 蔭荫 蘋苹 蝕蚀 蠅蝇 衊蔑 衹只 裊袅 褻亵 覲觐 訝讶 訥讷 詛诅 詐诈 誅诛 誣诬 誡诫 諄谆 諜谍 諧谐 謹谨 謬谬 譴谴 讀读 贅赘 贓赃 趨趋 蹤踪 輕轻 轟轰 辮辫 辭辞 邏逻 鄧邓 鄺邝 醞酝 釘钉 釵钗 鈍钝 鈔钞 鉤钩 鈕钮 鉅巨 鐲镯 鑄铸 鑒鉴 鑲镶 閘闸 閨闺 閥阀 閱阅 隕陨 雛雏 霽霁 靄霭 鞏巩 韃鞑 響响 頁页 頒颁 頌颂 頗颇 頸颈 頰颊 頻频 顆颗 飢饥 餅饼 餵喂 饋馈 饞馋 駛驶 駭骇 驗验 驕骄 驚惊').split(/\s+/).filter(p => p.length === 2);
const T2S = new Map(), S2T = new Map();
const NO_REV = '台系干合只复里面发后么云于表困巨症';       // 簡→繁時有歧義的字,另外手動指定
for (const [t, s] of PAIRS) { T2S.set(t, s); if (t !== s && !NO_REV.includes(s) && !S2T.has(s)) S2T.set(s, t); }
[['后', '後'], ['发', '發'], ['里', '裡'], ['么', '麼'], ['云', '雲'], ['复', '復'], ['着', '著'], ['并', '並'], ['台', '臺']].forEach(([s, t]) => { if (s !== '台') S2T.set(s, t); });
const conv = (str, map) => { let o = ''; for (const ch of String(str || '')) o += map.get(ch) || ch; return o; };
const toS = s => conv(s, T2S), toT = s => conv(s, S2T);
const hasTrad = s => { for (const ch of String(s || '')) if (T2S.has(ch) && T2S.get(ch) !== ch) return true; return false; };
const hasSimp = s => { for (const ch of String(s || '')) if (S2T.has(ch)) return true; return false; };

// ---------- 小工具 ----------
const norm = s => toS(String(s || '')).toLowerCase().replace(/[^\p{L}\p{N}]+/gu, '');
const uniq = a => [...new Set(a.filter(Boolean))];
function bigrams(s) { const o = new Map(); for (let i = 0; i < s.length - 1; i++) { const g = s.slice(i, i + 2); o.set(g, (o.get(g) || 0) + 1); } return o; }
function sim(a, b) {
  a = norm(a); b = norm(b); if (!a || !b) return 0; if (a === b) return 1;
  const mn = Math.min(a.length, b.length), mx = Math.max(a.length, b.length);
  if (mn >= 2 && (a.includes(b) || b.includes(a))) return .7 + .28 * mn / mx;
  if (a.length < 2 || b.length < 2) return 0;
  const A = bigrams(a), B = bigrams(b); let hit = 0; A.forEach((n, g) => { hit += Math.min(n, B.get(g) || 0); });
  return 2 * hit / (a.length + b.length - 2);
}
const splitArtists = a => String(a || '').split(/,|、|&|;|\/|×|\bfeat\.?\b|\bft\.?\b|\bx\b|\band\b|和/i).map(s => s.replace(/VEVO$/i, '').trim()).filter(Boolean);
const cleanTitle = t => String(t || '').replace(/[\(\[（【「『].*?[\)\]）】」』]/g, ' ').replace(/\s[-–—|]\s.*$/, ' ').replace(/\b(feat|ft)\.?.*$/i, ' ').replace(/\s+/g, ' ').trim();
const decodeEnt = s => String(s || '').replace(/&#(\d+);/g, (_, n) => String.fromCodePoint(+n)).replace(/&#x([0-9a-f]+);/gi, (_, n) => String.fromCodePoint(parseInt(n, 16)))
  .replace(/&apos;/g, "'").replace(/&quot;/g, '"').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&amp;/g, '&');

async function getJSON(url, headers, ms = 6500) {
  const ac = new AbortController(), tm = setTimeout(() => ac.abort(), ms);
  try {
    const r = await fetch(url, { headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0 Safari/537.36', ...headers }, signal: ac.signal });
    if (!r.ok) return null;
    const tx = await r.text(); try { return JSON.parse(tx); } catch { return null; }
  } catch { return null; } finally { clearTimeout(tm); }
}

// ---------- LRC 解析 ----------
const CREDIT = /^(作\s*[词詞曲]|[词詞曲]\s*[:：]|编\s*曲|編\s*[曲寫]|制作人?|製作人?|监制|監製|混音|母带|母帶|录音|錄音|吉他|贝斯|貝斯|鼓|和声|和聲|企划|企劃|发行|發行|出品|OP|SP|ISRC|Lyrics?|Music|Composer|Arranger|Producer|Written|Words|Vocals?|by|词|詞|曲|唱|歌手|歌名|专辑|專輯|统筹|統籌|配唱|弦乐|弦樂|封面|营销|營銷)\s*[:：]/i;
const INSTR = /纯音乐|純音樂|没有填词|沒有填詞|暂无歌词|暫無歌詞|歌词正在整理|此歌曲为没有填词|instrumental/i;
function parseLrc(txt) {
  txt = String(txt || '').replace(/^\uFEFF/, '');
  const om = txt.match(/\[offset:\s*([+-]?\d+)\s*\]/i), off = om ? +om[1] / 1000 : 0, out = [];
  for (const raw of txt.split(/\r?\n/)) {
    if (/^\s*\[[a-zA-Z#]+:[^\]]*\]\s*$/.test(raw)) continue;
    const stamps = []; let m; const tsr = /\[(\d{1,3}):(\d{1,2})(?:[.:](\d{1,3}))?\]/g;
    while ((m = tsr.exec(raw))) stamps.push(+m[1] * 60 + +m[2] + (m[3] ? +('0.' + m[3]) : 0));
    if (!stamps.length) continue;
    let body = raw.replace(/\[\d{1,3}:\d{1,2}(?:[.:]\d{1,3})?\]/g, ''), words = null;
    if (/<\d+:\d+(?:[.:]\d+)?>/.test(body)) {          // 逐字 LRC:<00:12.30>字
      words = []; const re = /<(\d+):(\d+(?:[.:]\d+)?)>([^<]*)/g;
      while ((m = re.exec(body))) words.push({ t: +m[1] * 60 + parseFloat(m[2].replace(':', '.')), w: m[3] });
      body = body.replace(/<[^>]*>/g, '');
    }
    const text = body.replace(/\u3000/g, ' ').replace(/\s+/g, ' ').trim();
    let ct = null;
    if (words && words.length && stamps.length === 1) {
      ct = []; words.forEach((w, i) => {
        const cs = [...w.w.replace(/\s/g, '')], nt = i + 1 < words.length ? words[i + 1].t : w.t + .4 * Math.max(1, cs.length);
        cs.forEach((_, k) => ct.push(+(w.t + (nt - w.t) * k / cs.length - off).toFixed(3)));
      });
      if (ct.length !== [...text.replace(/\s/g, '')].length) ct = null;
    }
    for (const t of stamps) out.push({ t: +(t - off).toFixed(3), text, ...(ct ? { ct } : {}) });
  }
  out.sort((a, b) => a.t - b.t);
  const res = []; const n = out.length;
  out.forEach((l, i) => {
    if (l.text && CREDIT.test(l.text) && (l.t < 45 || i < 10 || i > n - 8)) return;     // 作詞作曲等版權行
    const p = res[res.length - 1];
    if (p && Math.abs(p.t - l.t) < .05) { if (!p.text && l.text) res[res.length - 1] = l; return; }   // 同一時間重複(雙語)只留第一行
    if (p && !p.text && !l.text) return;                                                              // 連續空行合併
    res.push(l);
  });
  while (res.length && !res[0].text) res.shift();
  return res;
}
const isInstrumental = txt => INSTR.test(String(txt || '').slice(0, 400)) && (String(txt || '').match(/\[\d/g) || []).length < 12;

// 純文字歌詞 → 依長度估時間(最後退路)
function estimateLines(plain, dur) {
  const rows = String(plain || '').split(/\r?\n/).map(s => s.replace(/\[[^\]]*\]/g, '').replace(/\s+/g, ' ').trim()).filter(s => s && !CREDIT.test(s));
  if (rows.length < 3) return [];
  const D = dur > 20 ? dur : 200, a = Math.min(18, D * .07), b = D * .93, w = rows.map(r => Math.max(3, [...r].length)), W = w.reduce((x, y) => x + y, 0);
  let acc = 0; return rows.map((r, i) => { const t = a + (b - a) * acc / W; acc += w[i]; return { t: +t.toFixed(2), text: r }; });
}

// ---------- 來源 ----------
const LRC_H = { 'User-Agent': 'RhythZah/0.20 (desktop lyrics)' };
async function srcLrclib(w) {
  const base = 'https://lrclib.net/api/', P = o => base + 'search?' + new URLSearchParams(o), a = w.artist, t = w.title, tS = toS(t), aS = toS(a);
  const jobs = [];
  if (a && t) jobs.push(getJSON(base + 'get?' + new URLSearchParams({ track_name: t, artist_name: a, ...(w.dur > 0 ? { duration: String(Math.round(w.dur)) } : {}) }), LRC_H).then(d => d ? [d] : []));
  jobs.push(getJSON(P(a ? { track_name: t, artist_name: a } : { q: t }), LRC_H));
  if (a) jobs.push(getJSON(P({ q: a + ' ' + t }), LRC_H));
  if (a && t !== w.rawTitle) jobs.push(getJSON(P({ track_name: w.rawTitle, artist_name: a }), LRC_H));
  if (tS !== t || aS !== a) jobs.push(getJSON(P({ q: (aS + ' ' + tS).trim() }), LRC_H));
  jobs.push(getJSON(P({ q: t }), LRC_H));
  const seen = new Set(), stubs = [];
  for (const res of await Promise.all(jobs)) for (const d of (Array.isArray(res) ? res : [])) {
    if (!d || seen.has(d.id) || d.instrumental) continue; seen.add(d.id);
    if (!d.syncedLyrics && !d.plainLyrics) continue;
    stubs.push({ src: 'lrclib', title: d.trackName, artist: d.artistName, dur: +d.duration || 0, load: async () => ({ synced: d.syncedLyrics, plain: d.plainLyrics }) });
  }
  return stubs;
}
async function srcNetease(w) {
  const H = { Referer: 'https://music.163.com/', Cookie: 'appver=2.0.2; os=pc' };
  const kws = uniq([(w.artist + ' ' + w.title).trim(), toS((w.artist + ' ' + w.title).trim()), toS(w.title)]).slice(0, 3), seen = new Set(), stubs = [];
  const rs = await Promise.all(kws.map(k => getJSON('https://music.163.com/api/search/get?' + new URLSearchParams({ s: k, type: '1', offset: '0', limit: '8', total: 'true' }), H)));
  for (const d of rs) for (const s of ((d && d.result && d.result.songs) || [])) {
    if (seen.has(s.id)) continue; seen.add(s.id);
    stubs.push({ src: 'netease', title: s.name, artist: (s.artists || s.ar || []).map(x => x.name).join(' / '), dur: (+s.duration || +s.dt || 0) / 1000,
      load: async () => { const d2 = await getJSON(`https://music.163.com/api/song/lyric?id=${s.id}&lv=1&kv=1&tv=-1`, H); const l = d2 && d2.lrc && d2.lrc.lyric; return { synced: l, plain: l }; } });
  }
  return stubs;
}
async function srcKugou(w) {
  const kw = (w.artist ? w.artist + ' - ' : '') + w.title, ms = w.dur > 0 ? Math.round(w.dur * 1000) : 0, stubs = [], seen = new Set();
  const rs = await Promise.all(uniq([kw, toS(kw)]).map(k => getJSON('https://lyrics.kugou.com/search?' + new URLSearchParams({ ver: '1', man: 'yes', client: 'pc', keyword: k, duration: String(ms), hash: '' }))));
  for (const d of rs) for (const c of ((d && d.candidates) || []).slice(0, 6)) {
    if (seen.has(c.id)) continue; seen.add(c.id);
    stubs.push({ src: 'kugou', title: c.song, artist: c.singer, dur: (+c.duration || 0) / 1000,
      load: async () => { const d2 = await getJSON('https://lyrics.kugou.com/download?' + new URLSearchParams({ ver: '1', client: 'pc', id: String(c.id), accesskey: c.accesskey, fmt: 'lrc', charset: 'utf8' }));
        const l = d2 && d2.content ? Buffer.from(d2.content, 'base64').toString('utf8') : null; return { synced: l, plain: l }; } });
  }
  return stubs;
}
async function srcQQ(w) {
  const H = { Referer: 'https://y.qq.com/' }, stubs = [], seen = new Set();
  const rs = await Promise.all(uniq([(w.artist + ' ' + w.title).trim(), toS((w.artist + ' ' + w.title).trim())]).map(k => getJSON('https://c.y.qq.com/splcloud/fcgi-bin/smartbox_new.fcg?' + new URLSearchParams({ key: k, format: 'json' }), H)));
  for (const d of rs) for (const s of ((d && d.data && d.data.song && d.data.song.itemlist) || []).slice(0, 6)) {
    if (!s.mid || seen.has(s.mid)) continue; seen.add(s.mid);
    stubs.push({ src: 'qq', title: s.name, artist: s.singer, dur: 0,
      load: async () => { const d2 = await getJSON('https://c.y.qq.com/lyric/fcgi-bin/fcg_query_lyric_new.fcg?' + new URLSearchParams({ songmid: s.mid, g_tk: '5381', format: 'json', inCharset: 'utf8', outCharset: 'utf-8', nobase64: '1' }), H);
        let l = d2 && d2.lyric; if (l && !/^\s*\[/.test(l)) { try { l = Buffer.from(l, 'base64').toString('utf8'); } catch {} } l = l ? decodeEnt(l) : null; return { synced: l, plain: l }; } });
  }
  return stubs;
}
const SOURCES = [['lrclib', srcLrclib, .04], ['netease', srcNetease, .035], ['qq', srcQQ, .03], ['kugou', srcKugou, .02]];

// ---------- 評分 ----------
let PREF_TRAD = true;
const setPrefTrad = v => { PREF_TRAD = !!v; };
function simpRatio(c) { if (c._sr == null) { let h = 0, n = 0; for (const l of c.lines || []) for (const ch of (l.text || '')) if (/[\u3400-\u9fff]/.test(ch)) { n++; if (S2T.has(ch)) h++; } c._sr = n ? h / n : 0; } return c._sr; }
function metaScore(c, w, dur) {
  const ts = Math.max(sim(c.title, w.title), sim(c.title, w.rawTitle || w.title)), arts = splitArtists(w.artist);
  const as = !arts.length ? .5 : Math.max(0, ...arts.map(a => Math.max(sim(c.artist, a), splitArtists(c.artist).reduce((m, x) => Math.max(m, sim(x, a)), 0))));
  let ds = .35;
  if (dur > 0 && c.dur > 0) { const d = Math.abs(c.dur - dur); ds = d <= 1.5 ? 1 : d <= 3 ? .85 : d <= 6 ? .55 : d <= 12 ? .2 : -.3; }
  return { ts, as, ds, s: .45 * ts + .2 * as + .3 * ds };
}
function score(c, w, dur) {
  const m = metaScore(c, w, dur); let q = 0;
  if (c.lines && c.lines.length && !c.est) {
    const last = c.lines[c.lines.length - 1].t;
    if (dur > 0) { if (last > dur + 2.5) q -= .25; else if (last / dur > .55) q += .08; }
    q += Math.min(.06, c.lines.length / 600) + (c.lines.some(l => l.ct) ? .03 : 0);
  }
  if (c.est) q -= .6;
  if (PREF_TRAD && !c.est && simpRatio(c) > .03) q -= .12;   // 想看繁體:原本就是繁體的來源優先(簡體的轉繁體可能有少數字轉不到)
  return { ts: m.ts, s: m.s + q + (c.prior || 0) };
}
function pick(cands, w, dur) {
  if (!cands || !cands.length) return null;
  let best = null, bs = -9;
  for (const c of cands) {
    const sc = score(c, w, dur); if (sc.ts < .5 && !c.est) continue;
    if (c.est && dur > 0) c.lines = estimateLines(c.plain, dur);
    if (sc.s > bs) { bs = sc.s; best = c; }
  }
  if (best) best.score = bs;
  return best;
}

// ---------- 轉繁 / 轉簡(依歌曲名稱的字體自動判斷)----------
function convertLines(lines, mode, w) {
  if (!lines) return lines;
  let to = mode === 'simp' ? 's' : mode === 'off' ? '' : 't';   // 預設一律繁體
  if (!to) return lines;
  const f = to === 't' ? toT : toS;
  return lines.map(l => (l.text && /[\u3400-\u9fff]/.test(l.text)) ? { ...l, text: f(l.text) } : l);
}

// ---------- 抓取器 ----------
class LyricFetcher {
  constructor({ cacheFile, log }) {
    this.log = log || (() => {}); this.file = cacheFile; this.mem = new Map(); this.bad = new Map(); this.timer = 0;
    try { const o = JSON.parse(fs.readFileSync(cacheFile, 'utf8')); Object.entries(o).forEach(([k, v]) => this.mem.set(k, v)); } catch {}
  }
  keyOf(w) { return norm(w.artist) + '|' + norm(w.title); }
  save() {
    clearTimeout(this.timer);
    this.timer = setTimeout(() => {
      try { while (this.mem.size > 400) this.mem.delete(this.mem.keys().next().value); fs.writeFileSync(this.file, JSON.stringify(Object.fromEntries(this.mem))); } catch (e) { this.log('lyric cache save failed: ' + e.message); }
    }, 1500);
  }
  forget(want) { const k = this.keyOf({ title: cleanTitle(want.title) || want.title || '', artist: splitArtists(want.artist)[0] || '' }); this.mem.delete(k); this.bad.delete(k); this.save(); }
  /* want: { title, artist, dur }。onUpdate(cands) 會在每個來源回來時呼叫,可以先顯示最快的。回傳完整候選陣列。 */
  async fetch(want, onUpdate) {
    const w = { rawTitle: want.title || '', title: cleanTitle(want.title) || want.title || '', artist: splitArtists(want.artist)[0] || '', dur: want.dur || 0 };
    const key = this.keyOf(w), hit = this.mem.get(key);
    if (hit && hit.length) { hit.forEach(c => { c.prior = 0; }); return { w, cands: hit, cached: true }; }
    if (this.bad.get(key) > Date.now()) return { w, cands: [], cached: true };
    const all = []; let plainBest = null;
    const run = async ([name, fn, prior]) => {
      let stubs = []; try { stubs = await fn(w); } catch (e) { this.log(`lyrics ${name} search failed: ${e.message}`); }
      const ranked = stubs.map(s => ({ s, m: metaScore(s, w, w.dur) })).filter(x => x.m.ts >= .5).sort((a, b) => b.m.s - a.m.s).slice(0, 3);
      await Promise.all(ranked.map(async ({ s }) => {
        try {
          const r = await s.load(); if (!r) return;
          if (isInstrumental(r.synced || r.plain)) return;
          const lines = r.synced ? parseLrc(r.synced) : [];
          if (lines.length >= 4) all.push({ src: name, title: s.title, artist: s.artist, dur: s.dur, lines, prior });
          else if (r.plain && (!plainBest || r.plain.length > plainBest.plain.length)) plainBest = { src: name, title: s.title, artist: s.artist, dur: s.dur, plain: r.plain, est: true, lines: [], prior: 0 };
          if (onUpdate && all.length) onUpdate(all.slice());
        } catch (e) { this.log(`lyrics ${name} load failed: ${e.message}`); }
      }));
    };
    await Promise.all(SOURCES.map(run));
    if (!all.length && plainBest) { plainBest.lines = estimateLines(plainBest.plain, w.dur); if (plainBest.lines.length) all.push(plainBest); }
    const srcs = [...new Set(all.map(c => c.src))].join('+') || '-';
    this.log(`lyrics: ${all.length} candidates from ${srcs}`);
    if (all.length) { this.mem.set(key, all.slice(0, 6).map(c => ({ ...c, lines: c.lines }))); this.save(); } else this.bad.set(key, Date.now() + 60000);
    return { w, cands: all };
  }
}

module.exports = { setPrefTrad, LyricFetcher, parseLrc, pick, convertLines, estimateLines, sim, toS, toT, hasTrad, hasSimp, cleanTitle, splitArtists, norm };
