# RhythZah - Windows now-playing reader (SMTC).
# $CmdDir and $ParentPid are injected by the launcher (the script is passed with -EncodedCommand).
try { [Console]::OutputEncoding = [System.Text.Encoding]::UTF8 } catch {}
$ProgressPreference = 'SilentlyContinue'
$LogFile = Join-Path $env:TEMP 'ibaila-ps.log'
try { Set-Content -Path $LogFile -Value 'start' } catch {}

function Emit($o) {
  $j = $o | ConvertTo-Json -Compress
  try { [Console]::Out.WriteLine($j); [Console]::Out.Flush() } catch { Write-Output $j }
}
function Log($m) {
  Emit @{ type = 'log'; msg = "$m" }
  try { Add-Content -Path $LogFile -Value ((Get-Date).ToString('HH:mm:ss') + ' ' + $m) } catch {}
}
Log ('ps started, PowerShell ' + $PSVersionTable.PSVersion.ToString() + ', 64-bit process: ' + [Environment]::Is64BitProcess)

try {
  Add-Type -AssemblyName System.Runtime.WindowsRuntime
  $asTask = ([System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object {
    $_.Name -eq 'AsTask' -and $_.GetParameters().Count -eq 1 -and $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncOperation`1' })[0]
} catch { Log ('init failed (AsTask): ' + $_.Exception.Message); exit }

function Await($op, $type) {
  $t = $asTask.MakeGenericMethod($type).Invoke($null, @($op))
  $t.Wait(-1) | Out-Null
  $t.Result
}

try {
  $null = [Windows.Media.Control.GlobalSystemMediaTransportControlsSessionManager, Windows.Media.Control, ContentType = WindowsRuntime]
  $null = [Windows.Media.Control.GlobalSystemMediaTransportControlsSessionMediaProperties, Windows.Media.Control, ContentType = WindowsRuntime]
  $null = [Windows.Storage.Streams.IRandomAccessStreamWithContentType, Windows.Storage.Streams, ContentType = WindowsRuntime]
  $null = [Windows.Storage.Streams.DataReader, Windows.Storage.Streams, ContentType = WindowsRuntime]
  $null = [Windows.Storage.Streams.IInputStream, Windows.Storage.Streams, ContentType = WindowsRuntime]
  $null = [Windows.Storage.Streams.IRandomAccessStream, Windows.Storage.Streams, ContentType = WindowsRuntime]
  $mgr = Await ([Windows.Media.Control.GlobalSystemMediaTransportControlsSessionManager]::RequestAsync()) ([Windows.Media.Control.GlobalSystemMediaTransportControlsSessionManager])
} catch { Log ('init failed (SMTC): ' + $_.Exception.Message); exit }
Log 'smtc ready'

$filter = 'auto'
$cache = @{}

function Get-Kind($x) {
  $id = ("" + $x.SourceAppUserModelId).ToLower()
  if ($id -like '*spotify*') { return 'spotify' }
  if ($id -like '*applemusic*' -or $id -like '*itunes*' -or $id -like '*apple*') { return 'apple' }
  if ($id -match 'chrome|edge|firefox|brave|opera|vivaldi') { return 'browser' }
  return 'other'
}
# Browsers cannot tell YouTube from YouTube Music: guess by album title (YouTube Music has one, YouTube does not).
function Get-Album($x) {
  $id = "" + $x.SourceAppUserModelId
  $c = $cache[$id]
  if ($c -and ((Get-Date) - $c.t).TotalSeconds -lt 1.5) { return $c.album }
  $pp = Await ($x.TryGetMediaPropertiesAsync()) ([Windows.Media.Control.GlobalSystemMediaTransportControlsSessionMediaProperties])
  $album = "" + $pp.AlbumTitle
  $cache[$id] = @{ t = (Get-Date); album = $album }
  return $album
}
function Test-Match($x, $f) {
  $k = Get-Kind $x
  if ($f -eq 'spotify') { return ($k -eq 'spotify') }
  if ($f -eq 'apple') { return ($k -eq 'apple') }
  if ($f -eq 'ytmusic') { return ($k -eq 'browser' -and (Get-Album $x) -ne '') }
  if ($f -eq 'youtube') { return ($k -eq 'browser' -and (Get-Album $x) -eq '') }
  return $true
}
function Select-Session($f) {
  if ($f -eq 'auto') {
    $cur = $null
    try { $cur = $mgr.GetCurrentSession() } catch {}
    if ($cur) { return $cur }
    $all = @($mgr.GetSessions())
    foreach ($x in $all) { if (("" + $x.GetPlaybackInfo().PlaybackStatus) -eq 'Playing') { return $x } }
    if ($all.Count -gt 0) { return $all[0] }
    return $null
  }
  $cands = @()
  foreach ($x in $mgr.GetSessions()) { if (Test-Match $x $f) { $cands += $x } }
  if ($cands.Count -eq 0) { return $null }
  foreach ($x in $cands) { if (("" + $x.GetPlaybackInfo().PlaybackStatus) -eq 'Playing') { return $x } }
  return $cands[0]
}

# Fallback: when SMTC gives nothing, guess the song from window titles.
$script:wt = @{ t = [DateTime]::MinValue; v = $null; f = '' }
function Get-WindowTrack($f) {
  if ($script:wt.f -eq $f -and ((Get-Date) - $script:wt.t).TotalSeconds -lt 1.2) { return $script:wt.v }
  $res = $null
  try {
    $procs = @(Get-Process -ErrorAction SilentlyContinue | Where-Object { $_.MainWindowTitle })
    $wantSp = ($f -eq 'auto' -or $f -eq 'spotify')
    $wantAp = ($f -eq 'auto' -or $f -eq 'apple')
    if (-not $res -and $wantSp) {
      foreach ($p in ($procs | Where-Object { $_.ProcessName -eq 'Spotify' })) {
        $t = $p.MainWindowTitle.Trim()
        if ($t -and $t -notmatch '^Spotify( Free| Premium)?$' -and $t.Contains(' - ')) {
          $k = $t.IndexOf(' - ')
          $res = @{ artist = $t.Substring(0, $k); title = $t.Substring($k + 3); app = 'Spotify.exe' }; break
        }
      }
    }
    if (-not $res -and $wantAp) {
      foreach ($p in ($procs | Where-Object { $_.ProcessName -match 'AppleMusic|iTunes' })) {
        $t = $p.MainWindowTitle.Trim()
        if ($t -and $t -notmatch '^(Apple Music|iTunes)$') { $res = @{ artist = ''; title = $t; app = 'AppleMusic' }; break }
      }
    }
    if (-not $res) {
      foreach ($p in ($procs | Where-Object { $_.ProcessName -match 'chrome|msedge|firefox|brave|opera|vivaldi' })) {
        $t = $p.MainWindowTitle.Trim()
        $t = $t -replace '\s[-\u2013\u2014]\s(Google Chrome|Microsoft.{0,3}Edge|Brave|Mozilla Firefox|Opera|Vivaldi).*$', ''
        $t = $t -replace '^\(\d+\)\s*', ''
        $kind = ''
        if ($t -match '\s-\sYouTube Music$') { $kind = 'ytmusic'; $t = $t -replace '\s-\sYouTube Music$', '' }
        elseif ($t -match '\s-\sYouTube$') { $kind = 'youtube'; $t = $t -replace '\s-\sYouTube$', '' }
        if ($kind -and $t -and ($f -eq 'auto' -or $f -eq $kind)) {
          $a = ''; $ti = $t
          if ($kind -eq 'youtube' -and $t -match '^(.+?)\s[-\u2013\u2014]\s(.+)$') { $a = $Matches[1]; $ti = $Matches[2] }
          $res = @{ artist = $a; title = $ti; app = $p.ProcessName }; break
        }
      }
    }
  } catch { Log ('title fallback failed: ' + $_.Exception.Message) }
  $script:wt = @{ t = (Get-Date); v = $res; f = $f }
  return $res
}
# Save the thumbnail to a file (stream copy first, DataReader as fallback).
function Save-Thumb($p, $file) {
  $rs = Await ($p.Thumbnail.OpenReadAsync()) ([Windows.Storage.Streams.IRandomAccessStreamWithContentType])
  try {
    $net = [System.IO.WindowsRuntimeStreamExtensions]::AsStreamForRead([Windows.Storage.Streams.IInputStream]$rs)
    $fs = [System.IO.File]::Create($file)
    try { $net.CopyTo($fs) } finally { $fs.Close(); $net.Close() }
  } catch {
    Log ('thumb method A failed: ' + $_.Exception.Message)
    $ras = [Windows.Storage.Streams.IRandomAccessStream]$rs
    $size = [uint32]$ras.Size
    $reader = [Windows.Storage.Streams.DataReader]::new($ras.GetInputStreamAt(0))
    $null = Await ($reader.LoadAsync($size)) ([uint32])
    $bytes = New-Object byte[] $size
    $reader.ReadBytes($bytes)
    [System.IO.File]::WriteAllBytes($file, $bytes)
  }
  return ((Get-Item $file).Length -gt 0)
}

# ---- system volume ----
# mode 'core' = Windows Core Audio (exact, can read the current volume)
# mode 'keys' = fallback: media keys (VK_VOLUME_UP/DOWN/MUTE, 2% per press; the volume can't be read back)
# Compiled lazily so it never delays the first song.
$volInit = $false; $volMode = ''; $volLast = ''; $keyVol = -1; $keyMute = $false
function Init-Vol {
  if ($script:volInit) { return }
  $script:volInit = $true
  try {
Add-Type -TypeDefinition @'
using System;
using System.Text;
using System.Diagnostics;
using System.Runtime.InteropServices;
[ComImport, Guid("5CDF2C82-841E-4546-9722-0CF74078229A"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
interface IbEpVol {
  int NotImpl1(); int NotImpl2();
  int GetChannelCount(out uint c);
  int SetMasterVolumeLevel(float l, ref Guid g);
  int SetMasterVolumeLevelScalar(float l, ref Guid g);
  int GetMasterVolumeLevel(out float l);
  int GetMasterVolumeLevelScalar(out float l);
  int SetChannelVolumeLevel(uint n, float l, ref Guid g);
  int SetChannelVolumeLevelScalar(uint n, float l, ref Guid g);
  int GetChannelVolumeLevel(uint n, out float l);
  int GetChannelVolumeLevelScalar(uint n, out float l);
  int SetMute([MarshalAs(UnmanagedType.Bool)] bool m, ref Guid g);
  int GetMute([MarshalAs(UnmanagedType.Bool)] out bool m);
}
[ComImport, Guid("D666063F-1587-4E43-81F1-B948E807363F"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
interface IbDev { int Activate(ref Guid id, int ctx, IntPtr p, [MarshalAs(UnmanagedType.IUnknown)] out object o); }
[ComImport, Guid("A95664D2-9614-4F35-A746-DE8DB63617E6"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
interface IbEnum { int NotImpl1(); int GetDefaultAudioEndpoint(int flow, int role, out IbDev d); }
[ComImport, Guid("BCDE0395-E52F-49CF-9BD3-58DCCDCEC16B")] class IbEnumCom { }
public static class IbVol {
  [DllImport("ole32.dll")] static extern int CoCreateInstance(ref Guid clsid, IntPtr outer, uint ctx, ref Guid iid, out IntPtr p);
  [DllImport("user32.dll")] static extern void keybd_event(byte vk, byte scan, uint flags, UIntPtr extra);
  static IbEnum Enumerator() {
    try { return (IbEnum)(new IbEnumCom()); } catch (Exception) { }
    Guid clsid = new Guid("BCDE0395-E52F-49CF-9BD3-58DCCDCEC16B"), iid = typeof(IbEnum).GUID; IntPtr p;
    int hr = CoCreateInstance(ref clsid, IntPtr.Zero, 23, ref iid, out p);
    if (hr != 0) Marshal.ThrowExceptionForHR(hr);
    return (IbEnum)Marshal.GetObjectForIUnknown(p);
  }
  static IbEpVol Make() {
    IbEnum e = Enumerator();
    IbDev d; e.GetDefaultAudioEndpoint(0, 1, out d);
    Guid iid = typeof(IbEpVol).GUID; object o;
    d.Activate(ref iid, 23, IntPtr.Zero, out o);
    return (IbEpVol)o;
  }
  // 音量端點物件快取起來(每次都重建要好幾毫秒,拖曳滑桿會一頓一頓);幾秒換一次,以免換了喇叭還抓舊的
  static IbEpVol cache; static int cacheAt;
  static IbEpVol Ep() {
    int now = Environment.TickCount;
    if (cache == null || now - cacheAt > 4000 || now - cacheAt < 0) { cache = Make(); cacheAt = now; }
    return cache;
  }
  public static float Get() { try { float v; Ep().GetMasterVolumeLevelScalar(out v); return v; } catch (Exception) { cache = null; float w; Ep().GetMasterVolumeLevelScalar(out w); return w; } }
  public static void Set(float v) { Guid g = Guid.Empty; try { Ep().SetMasterVolumeLevelScalar(v, ref g); } catch (Exception) { cache = null; Ep().SetMasterVolumeLevelScalar(v, ref g); } }
  public static bool GetMute() { try { bool m; Ep().GetMute(out m); return m; } catch (Exception) { cache = null; bool n; Ep().GetMute(out n); return n; } }
  public static void SetMute(bool m) { Guid g = Guid.Empty; try { Ep().SetMute(m, ref g); } catch (Exception) { cache = null; Ep().SetMute(m, ref g); } }
  // Hide the Windows volume flyout (the black overlay at the top-left) that pops up after a volume change.
  [DllImport("user32.dll", CharSet = CharSet.Unicode)] static extern IntPtr FindWindowEx(IntPtr parent, IntPtr after, string cls, string title);
  [DllImport("user32.dll")] static extern bool ShowWindow(IntPtr h, int cmd);
  [DllImport("user32.dll")] static extern bool IsWindowVisible(IntPtr h);
  [DllImport("user32.dll")] static extern uint GetWindowThreadProcessId(IntPtr h, out uint pid);
  static int HideOsdOnce() {
    int n = 0; IntPtr h = IntPtr.Zero;
    while (true) {
      h = FindWindowEx(IntPtr.Zero, h, "NativeHWNDHost", null);
      if (h == IntPtr.Zero) break;
      if (!IsWindowVisible(h)) continue;
      if (FindWindowEx(h, IntPtr.Zero, "DirectUIHWND", null) == IntPtr.Zero) continue;
      uint pid; GetWindowThreadProcessId(h, out pid);
      try { if (Process.GetProcessById((int)pid).ProcessName.ToLower() != "explorer") continue; } catch (Exception) { continue; }
      ShowWindow(h, 0); n++;
    }
    return n;
  }
  // 背景執行緒:音量一變動就持續把系統音量浮窗藏起來(每 8 毫秒一次),不會卡住主流程,浮窗也不會閃出來
  static int osdUntil; static System.Threading.Thread osdTh;
  public static void ArmOsd(int ms) {
    osdUntil = Environment.TickCount + ms;
    if (osdTh == null) { osdTh = new System.Threading.Thread(OsdLoop); osdTh.IsBackground = true; osdTh.Start(); }
  }
  static void OsdLoop() {
    while (true) {
      if (osdUntil - Environment.TickCount > 0) { try { HideOsdOnce(); } catch (Exception) { } System.Threading.Thread.Sleep(8); }
      else System.Threading.Thread.Sleep(50);
    }
  }
  public static int HideOsd(int tries, int sleepMs) {
    int total = 0, quiet = 0;
    for (int i = 0; i < tries; i++) {
      int c = HideOsdOnce();
      total += c;
      if (c == 0 && total > 0) { quiet++; if (quiet >= 2) break; }
      System.Threading.Thread.Sleep(sleepMs);
    }
    return total;
  }
  public static void Key(byte vk, int n) {
    for (int i = 0; i < n; i++) { keybd_event(vk, 0, 0, UIntPtr.Zero); keybd_event(vk, 0, 2, UIntPtr.Zero); System.Threading.Thread.Sleep(6); }
  }
}
'@
  } catch { Log ('volume code could not be compiled: ' + $_.Exception.Message); return }
  try { $null = [IbVol]::Get(); $script:volMode = 'core'; Log 'volume: Core Audio ok' }
  catch { $script:volMode = 'keys'; Log ('volume: Core Audio unavailable (' + $_.Exception.Message + '), using media keys instead') }
}
function Emit-Vol($force) {
  try {
    if ($script:volMode -eq 'core') {
      $v = [int][math]::Round([IbVol]::Get() * 100); $m = [bool][IbVol]::GetMute()
    } elseif ($script:volMode -eq 'keys' -and $script:keyVol -ge 0) {
      $v = $script:keyVol; $m = $script:keyMute
    } else { return }
    $k = "$v|$m"
    if ($force -or $k -ne $script:volLast) { $script:volLast = $k; Emit @{ type = 'volume'; v = $v; mute = $m } }
  } catch { Log ('volume read failed: ' + $_.Exception.Message); $script:volMode = 'keys' }
}
function Set-Vol([double]$v) {   # $v = 0..1
  if ($script:volMode -eq 'core') {
    [IbVol]::Set([float]$v)
    if ($v -gt 0 -and [IbVol]::GetMute()) { [IbVol]::SetMute($false) }
  } elseif ($script:volMode -eq 'keys') {
    $t = [int][math]::Round($v * 100)
    if ($script:keyVol -lt 0) { [IbVol]::Key(0xAE, 50); $script:keyVol = 0 }   # unknown start: go to 0 first
    $d = [int][math]::Round(($t - $script:keyVol) / 2.0)
    if ($d -gt 0) { [IbVol]::Key(0xAF, $d) } elseif ($d -lt 0) { [IbVol]::Key(0xAE, -$d) }
    $script:keyVol = $t
    if ($script:keyMute -and $t -gt 0) { [IbVol]::Key(0xAD, 1); $script:keyMute = $false }
  }
}
function Toggle-Mute {
  if ($script:volMode -eq 'core') { [IbVol]::SetMute(-not [IbVol]::GetMute()) }
  elseif ($script:volMode -eq 'keys') { [IbVol]::Key(0xAD, 1); $script:keyMute = -not $script:keyMute }
}


# 音量指令走快速通道:主迴圈之外每 40 毫秒看一次;拖曳時一次湧進來好幾個,只做最新的那個,滑桿才會順
function Apply-Vol($cmd) {
  Init-Vol
  if (-not $script:volMode) { return }
  try {
    $v = [double]::Parse($cmd.Substring(4), [Globalization.CultureInfo]::InvariantCulture) / 100.0
    if ($v -lt 0) { $v = 0 }; if ($v -gt 1) { $v = 1 }
    [IbVol]::ArmOsd(2500)
    Set-Vol $v
  } catch { Log ('set volume failed: ' + $_.Exception.Message) }
  Emit-Vol $true
}
function Fast-Cmds {
  try {
    if (-not $CmdDir -or -not [System.IO.Directory]::Exists($CmdDir)) { return }
    $files = [System.IO.Directory]::GetFiles($CmdDir, '*.cmd')
    if ($files.Length -eq 0) { return }
    [Array]::Sort($files)
    $vol = $null
    foreach ($f in $files) {
      $t = ''
      try { $t = ([System.IO.File]::ReadAllText($f)).Trim() } catch { break }
      if ($t -like 'vol:*') { $vol = $t; try { [System.IO.File]::Delete($f) } catch {} }
    }
    if ($vol) { Apply-Vol $vol }
  } catch { Log ('fast cmd failed: ' + $_.Exception.Message) }
}
function Poll-Wins {
  if (-not ($script:winOk -and $script:winOn)) { return }
  try {
    $r = [IbWin]::Rects([uint32]$ParentPid)
    if ($r -ne $script:winLast) { $script:winLast = $r; Emit @{ type = 'wins'; r = $r; aware = $script:winAware } }
  } catch { Log ('window list failed: ' + $_.Exception.Message) }
}

$last = ''; $pend = ''; $tries = 0; $n = 0; $i = 0; $lastIds = $null
$sent = $false; $sleepMs = 200; $fsInit = $false; $fsOk = $false; $fsLast = -1
$winOn = $false; $winInit = $false; $winOk = $false; $winLast = $null; $winAware = $false
$lastPos = -100.0; $lastPlaying = $null; $lastDur = -1.0; $lastAt = Get-Date; $wasNone = $false

while ($true) {
  if ($ParentPid -gt 0 -and ($i % 20) -eq 0) {
    if (-not (Get-Process -Id $ParentPid -ErrorAction SilentlyContinue)) { exit }
  }
  $s = $null
  try { $s = Select-Session $filter } catch { Log ('select failed: ' + $_.Exception.Message) }

  # list the media sources that exist (debug)
  if (($i % 5) -eq 0) {
    try {
      $ids = (@($mgr.GetSessions() | ForEach-Object { $_.SourceAppUserModelId }) -join ', ')
      if ($ids -ne $lastIds) { Log ('sessions: [' + $ids + '] filter=' + $filter); $lastIds = $ids }
    } catch {}
  }

  # commands from the app: small .cmd files in $CmdDir
  try {
    if ($CmdDir -and (Test-Path $CmdDir)) {
      foreach ($f in ([System.IO.Directory]::GetFiles($CmdDir, '*.cmd') | Sort-Object)) {
        $cmd = ''
        try { $cmd = ([System.IO.File]::ReadAllText($f)).Trim(); [System.IO.File]::Delete($f) } catch { break }
        if ($cmd -like 'source:*') {
          $filter = $cmd.Substring(7)
          $last = ''; $pend = ''; $lastPlaying = $null; $wasNone = $false; $i = 0
          $s = Select-Session $filter
        } elseif ($cmd -like 'wins:*') {
          $script:winOn = ($cmd -eq 'wins:on'); $script:winLast = $null
        } elseif ($cmd -like 'rate:*') {
          if ($cmd -eq 'rate:slow') { $sleepMs = 600 } else { $sleepMs = 200 }
        } elseif ($cmd -like 'vol:*') {
          Apply-Vol $cmd
        } elseif ($cmd -eq 'mute:toggle') {
          Init-Vol
          if ($volMode) {
            try { Toggle-Mute; [IbVol]::ArmOsd(2500) } catch { Log ('mute failed: ' + $_.Exception.Message) }
            Emit-Vol $true
          }
        } elseif ($s) {
          if ($cmd -eq 'toggle') { $null = Await ($s.TryTogglePlayPauseAsync()) ([bool]) }
          elseif ($cmd -eq 'next') { $null = Await ($s.TrySkipNextAsync()) ([bool]) }
          elseif ($cmd -eq 'prev') { $null = Await ($s.TrySkipPreviousAsync()) ([bool]) }
          elseif ($cmd -like 'seek:*') {
            $sec = [double]::Parse($cmd.Substring(5), [Globalization.CultureInfo]::InvariantCulture)
            $null = Await ($s.TryChangePlaybackPositionAsync([long]($sec * 10000000))) ([bool])
          }
          $lastPos = -100.0
        }
      }
    }
  } catch { Log ('command failed: ' + $_.Exception.Message) }

  try {
    if ($s) {
      $wasNone = $false
      $appId = "" + $s.SourceAppUserModelId
      # track info + cover (checked every loop so a new song shows up right away)
      if ($true) {
        try {
          $p = Await ($s.TryGetMediaPropertiesAsync()) ([Windows.Media.Control.GlobalSystemMediaTransportControlsSessionMediaProperties])
          $pTitle = '' + $p.Title; $pArtist = '' + $p.Artist
          if ($pTitle -eq '' -and $pArtist -eq '') {
            $w = Get-WindowTrack $filter
            if ($w) { $pTitle = $w.title; $pArtist = $w.artist; Log ('title from window: ' + $pArtist + ' - ' + $pTitle) }
          }
          $key = $appId + '|' + $pArtist + '|' + $pTitle
          if ($key -ne $last) {
            if ($key -ne $pend) { $pend = $key; $tries = 0; $sent = $false }
            if (-not $sent -and ($pTitle -ne '' -or $pArtist -ne '')) {
              $sent = $true
              Emit @{ type = 'track'; key = $key; title = $pTitle; artist = $pArtist; thumb = ''; app = $appId; pending = $true }
            }
            $thumb = ''
            if ($p.Thumbnail) {
              $n = ($n + 1) % 6
              $file = Join-Path $env:TEMP ('ibaila-thumb-' + $n + '.img')
              try { if (Save-Thumb $p $file) { $thumb = $file } } catch { Log ('thumb failed: ' + $_.Exception.Message) }
            } elseif ($tries -eq 0) { Log ('no thumbnail offered by ' + $appId) }
            # the cover sometimes arrives late: retry for about 1.5 seconds
            if ($thumb -ne '' -or $tries -ge 8) {
              $last = $key
              Emit @{ type = 'cover'; key = $key; thumb = $thumb }
            } else { $tries++ }
          }
        } catch { Log ('media properties failed: ' + $_.Exception.Message); $tries++ }
      }
      # playback state / position
      $info = $s.GetPlaybackInfo()
      $tl = $s.GetTimelineProperties()
      $playing = (("" + $info.PlaybackStatus) -eq 'Playing')
      $dur = ($tl.EndTime - $tl.StartTime).TotalSeconds
      $pos = $tl.Position.TotalSeconds
      if ($playing) { $pos += ([DateTimeOffset]::Now - $tl.LastUpdatedTime).TotalSeconds }
      if ($dur -gt 0 -and $pos -gt $dur) { $pos = $dur }
      if ($pos -lt 0) { $pos = 0 }
      $now = Get-Date
      $elapsed = ($now - $lastAt).TotalSeconds
      $expected = $lastPos
      if ($lastPlaying) { $expected = $lastPos + $elapsed }
      if ($playing -ne $lastPlaying -or $dur -ne $lastDur -or [math]::Abs($pos - $expected) -gt 0.3 -or $elapsed -gt 3) {
        Emit @{ type = 'state'; playing = $playing; pos = [math]::Round($pos, 1); dur = [math]::Round($dur, 1) }
        $lastPos = $pos; $lastPlaying = $playing; $lastDur = $dur; $lastAt = $now
      }
    } else {
      $w = $null
      if (($i % 4) -eq 0) { $w = Get-WindowTrack $filter }
      if ($w) {
        $wasNone = $false
        $k = 'win|' + $w.artist + '|' + $w.title
        if ($k -ne $last) {
          $last = $k; Log ('fallback (window title): ' + $w.artist + ' - ' + $w.title)
          Emit @{ type = 'track'; key = $k; title = $w.title; artist = $w.artist; thumb = ''; app = $w.app }
          Emit @{ type = 'state'; playing = $true; pos = 0; dur = 0 }
          $lastPlaying = $true; $lastPos = 0.0; $lastDur = 0.0; $lastAt = Get-Date
        }
      } elseif (-not $wasNone -and (($i % 4) -eq 0)) {
        $wasNone = $true; $last = ''; $lastPlaying = $null
        Emit @{ type = 'state'; none = $true }
      }
    }
  } catch { Log ('loop failed: ' + $_.Exception.Message) }
  # fullscreen check: compiled late so it never delays the first song
  if (-not $fsInit -and $i -ge 40) {
    $fsInit = $true
    try {
Add-Type -TypeDefinition @'
using System.Runtime.InteropServices;
public static class IbFs { [DllImport("shell32.dll")] public static extern int SHQueryUserNotificationState(out int s); }
'@
      $fsOk = $true
    } catch { Log ('fullscreen check unavailable: ' + $_.Exception.Message) }
  }
  if ($fsOk -and ($i % 5) -eq 0) {
    try {
      $q = 0
      $null = [IbFs]::SHQueryUserNotificationState([ref]$q)
      if ($q -ne $fsLast) { $fsLast = $q; Emit @{ type = 'fs'; q = [int]$q } }
    } catch {}
  }
  # 桌面專用歌詞:列出「會擋住桌面」的視窗(有畫面、沒最小化、不是桌面/工作列/本程式自己),交給主程式判斷有沒有蓋到歌詞
  if (-not $winInit -and $i -ge 10) {
    $winInit = $true
    try {
Add-Type -TypeDefinition @'
using System; using System.Text; using System.Runtime.InteropServices;
public static class IbWin {
  delegate bool EnumProc(IntPtr h, IntPtr l);
  [DllImport("user32.dll")] static extern bool EnumWindows(EnumProc p, IntPtr l);
  [DllImport("user32.dll")] static extern bool IsWindowVisible(IntPtr h);
  [DllImport("user32.dll")] static extern bool IsIconic(IntPtr h);
  [DllImport("user32.dll")] static extern bool GetWindowRect(IntPtr h, out RECT r);
  [DllImport("user32.dll", EntryPoint = "GetWindowLongW")] static extern int GetWindowLong(IntPtr h, int i);
  [DllImport("user32.dll", CharSet = CharSet.Unicode)] static extern int GetClassName(IntPtr h, StringBuilder s, int n);
  [DllImport("user32.dll")] static extern uint GetWindowThreadProcessId(IntPtr h, out uint pid);
  [DllImport("dwmapi.dll")] static extern int DwmGetWindowAttribute(IntPtr h, int a, out int v, int sz);
  [DllImport("user32.dll")] static extern bool SetProcessDPIAware();
  [DllImport("user32.dll")] static extern bool IsProcessDPIAware();
  [StructLayout(LayoutKind.Sequential)] struct RECT { public int L, T, R, B; }
  public static bool Aware() { try { SetProcessDPIAware(); return IsProcessDPIAware(); } catch { return false; } }
  static readonly string[] Skip = { "Progman", "WorkerW", "Shell_TrayWnd", "Shell_SecondaryTrayWnd", "NotifyIconOverflowWindow", "TopLevelWindowForOverflowXamlIsland", "XamlExplorerHostIslandWindow", "Windows.UI.Core.CoreWindow", "ForegroundStaging", "MultitaskingViewFrame" };
  public static string Rects(uint skipPid) {
    var sb = new StringBuilder(); var cls = new StringBuilder(256);
    EnumWindows((h, l) => {
      if (!IsWindowVisible(h) || IsIconic(h)) return true;
      int cloaked; if (DwmGetWindowAttribute(h, 14, out cloaked, 4) == 0 && cloaked != 0) return true;
      int ex = GetWindowLong(h, -20);
      if ((ex & 0x20) != 0 || (ex & 0x80) != 0) return true;           // 點擊穿透 / 工具視窗
      uint pid; GetWindowThreadProcessId(h, out pid); if (pid == skipPid) return true;
      cls.Clear(); GetClassName(h, cls, 256); string c = cls.ToString();
      foreach (var s in Skip) if (c == s) return true;
      RECT r; if (!GetWindowRect(h, out r)) return true;
      if (r.R - r.L < 40 || r.B - r.T < 40) return true;
      sb.Append(r.L).Append(',').Append(r.T).Append(',').Append(r.R).Append(',').Append(r.B).Append(';');
      return true;
    }, IntPtr.Zero);
    return sb.ToString();
  }
}
'@
      $winAware = [IbWin]::Aware(); $winOk = $true; Log ('desktop-only lyrics ready (dpiAware=' + $winAware + ')')
    } catch { Log ('desktop-only lyrics unavailable: ' + $_.Exception.Message) }
  }
  # volume: compile once after startup, then pick up changes made elsewhere (keyboard, mixer) every few seconds
  if (-not $volInit -and $i -ge 45) { Init-Vol; Emit-Vol $true }
  elseif ($volMode -eq 'core' -and ($i % 8) -eq 0) { Emit-Vol $false }
  $i++
  # 每 40 毫秒:處理音量指令、檢查有沒有視窗蓋到歌詞(很輕);其餘工作仍是每 $sleepMs 一次
  $sw = [System.Diagnostics.Stopwatch]::StartNew()
  do {
    Start-Sleep -Milliseconds 40
    Fast-Cmds
    Poll-Wins
  } while ($sw.ElapsedMilliseconds -lt $sleepMs)
}
