/* RhythZah 音效引擎(Web Audio 即時合成,不需要音檔)
   質感:深沉的低頻下沉 + 液體般打開的濾波掃頻 + 玻璃五度音 + 落定的低頻重擊(參考 Apple Music 動態標誌)
   用法:AM.config({sfx,bgm,vol}) / AM.sfx('intro'|'hover'|'select'|'toggle'|'next'|'back'|'done'|'open') / AM.start() / AM.bind(document) */
(function () {
  'use strict';
  const AC = window.AudioContext || window.webkitAudioContext;
  const A = { cfg: { sfx: true, bgm: true, vol: 0.8 } };
  let ctx, master, verb, noiseBuf, bgm = null, wantBgm = false, focused = true, lastHover = 0, hoverEl = null;

  function impulse(sec, dec) {
    const sr = ctx.sampleRate, n = Math.floor(sr * sec), b = ctx.createBuffer(2, n, sr);
    for (let c = 0; c < 2; c++) { const d = b.getChannelData(c); for (let i = 0; i < n; i++) d[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / n, dec); }
    return b;
  }
  function ensure() {
    if (ctx) return ctx;
    ctx = window.__AM_CTX || new AC();
    master = ctx.createGain(); master.gain.value = A.cfg.vol;
    const comp = ctx.createDynamicsCompressor(); comp.threshold.value = -14; comp.ratio.value = 3;
    master.connect(comp); comp.connect(ctx.destination);
    verb = ctx.createConvolver(); verb.buffer = impulse(3, 2.4);
    const vg = ctx.createGain(); vg.gain.value = 0.7; verb.connect(vg); vg.connect(master);
    const len = Math.floor(ctx.sampleRate * 2); noiseBuf = ctx.createBuffer(1, len, ctx.sampleRate);
    const d = noiseBuf.getChannelData(0); for (let i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;
    return ctx;
  }
  const now = () => ctx.currentTime + 0.02;
  function route(node, wet) {
    node.connect(master);
    if (wet) { const s = ctx.createGain(); s.gain.value = wet; node.connect(s); s.connect(verb); }
  }
  /* 短音(玻璃 / 點擊)*/
  function tone(f, t, o) {
    o = o || {}; const a = o.a == null ? 0.005 : o.a, d = o.d == null ? 0.4 : o.d, v = o.v == null ? 0.1 : o.v;
    const os = ctx.createOscillator(), g = ctx.createGain(); os.type = o.type || 'sine';
    os.frequency.setValueAtTime(f, t); if (o.to) os.frequency.exponentialRampToValueAtTime(o.to, t + a + d);
    g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(v, t + a); g.gain.exponentialRampToValueAtTime(0.0001, t + a + d);
    os.connect(g); route(g, o.wet || 0); os.start(t); os.stop(t + a + d + 0.05);
  }
  /* 低頻漲落(下沉 / 落定)*/
  function swell(f, t, a, hold, d, v) {
    [[f, 1], [f * 2, 0.8], [f * 3, 0.45], [f * 4, 0.2]].forEach(([fr, k]) => {
      const os = ctx.createOscillator(), g = ctx.createGain(); os.type = 'sine'; os.frequency.setValueAtTime(fr * 0.82, t); os.frequency.exponentialRampToValueAtTime(fr, t + a);
      g.gain.setValueAtTime(0.0001, t); g.gain.linearRampToValueAtTime(v * k, t + a); g.gain.setValueAtTime(v * k, t + hold); g.gain.linearRampToValueAtTime(0.0001, t + d);
      os.connect(g); g.connect(master); os.start(t); os.stop(t + d + 0.05);
    });
  }
  /* 濾波掃頻(液體 / 風切)*/
  function sweep(f0, f1, t, dur, v, wet, q) {
    const src = ctx.createBufferSource(); src.buffer = noiseBuf; src.loop = true;
    const bp = ctx.createBiquadFilter(); bp.type = 'bandpass'; bp.Q.value = q || 3; bp.frequency.setValueAtTime(f0, t); bp.frequency.exponentialRampToValueAtTime(f1, t + dur);
    const g = ctx.createGain(); g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(v, t + dur * 0.65); g.gain.exponentialRampToValueAtTime(0.0001, t + dur * 1.25);
    src.connect(bp); bp.connect(g); route(g, wet == null ? 0.4 : wet); src.start(t); src.stop(t + dur * 1.3 + 0.1);
  }
  const thud = (t, v) => tone(120, t, { a: 0.004, d: 0.55, v: v || 0.5, to: 44 });

  const FX = {
    /* 歡迎開場:對應畫面 玻璃泡(0s)→ 方形圖示(0.9s)→ 標誌(1.3s)*/
    intro(t) {
      swell(48, t, 0.55, 1.5, 2.5, 0.2);
      tone(185, t, { a: 0.5, d: 1.7, v: 0.1, wet: 0.3 });
      sweep(250, 3200, t, 1.2, 0.28, 0.35, 2.2);
      tone(370, t + 0.95, { d: 2.2, v: 0.11, wet: 0.8 }); tone(555, t + 0.97, { d: 2.2, v: 0.08, wet: 0.8 }); tone(1110, t + 1.0, { d: 1.6, v: 0.025, wet: 0.9 });
      thud(t + 1.35, 0.34); tone(740, t + 1.45, { d: 1.8, v: 0.04, wet: 0.9 });
    },
    open(t) { sweep(300, 2200, t, 0.5, 0.07, 0.5, 2.5); swell(55, t, 0.25, 0.4, 1.2, 0.3); tone(555, t + 0.3, { d: 1.6, v: 0.08, wet: 0.8 }); tone(830, t + 0.36, { d: 1.4, v: 0.05, wet: 0.8 }); },
    hover(t) { tone(2000 + Math.random() * 300, t, { a: 0.002, d: 0.05, v: 0.022, wet: 0.2 }); },
    select(t) { tone(740, t, { d: 0.38, v: 0.085, wet: 0.6 }); tone(1110, t + 0.07, { d: 0.45, v: 0.06, wet: 0.6 }); },
    toggleOn(t) { tone(520, t, { a: 0.004, d: 0.14, v: 0.09, to: 800, wet: 0.2 }); },
    toggleOff(t) { tone(800, t, { a: 0.004, d: 0.14, v: 0.07, to: 480, wet: 0.2 }); },
    page(t) { tone(1500, t, { a: 0.002, d: 0.09, v: 0.05, wet: 0.35 }); },
    next(t) { sweep(450, 2400, t, 0.3, 0.07, 0.4, 2); tone(110, t, { a: 0.01, d: 0.4, v: 0.25, to: 62 }); },
    back(t) { sweep(2200, 400, t, 0.28, 0.06, 0.4, 2); tone(90, t, { a: 0.01, d: 0.3, v: 0.18, to: 55 }); },
    /* 完成:低頻漲起 + 玻璃和弦 + 落定重擊 */
    done(t) {
      swell(55, t, 0.5, 1.0, 2.2, 0.2); sweep(300, 3200, t, 0.9, 0.2, 0.4, 2.2);
      [370, 555, 740, 1110].forEach((f, i) => tone(f, t + 0.7 + i * 0.09, { d: 2.4, v: [0.1, 0.08, 0.05, 0.03][i], wet: 0.9 }));
      thud(t + 0.95, 0.32);
    }
  };
  A.sfx = function (name) {
    if (!A.cfg.sfx || !AC) return; ensure(); A.unlock();
    if (name === 'toggle') name = arguments[1] ? 'toggleOn' : 'toggleOff';
    if (FX[name]) try { FX[name](now()); } catch (e) {}
  };

  /* ---- 背景音樂:暗色氛圍,四個和弦慢慢輪替,偶爾飄過一個玻璃音 ---- */
  const CH = [[55, 110, 164.8, 196, 261.6], [43.65, 87.3, 130.8, 164.8, 220], [65.4, 130.8, 196, 246.9, 329.6], [49, 98, 146.8, 196, 293.7]];
  const BGM_VOL = 0.2;
  function chord() {
    if (!bgm) return; const t = now(), notes = CH[bgm.i % CH.length]; bgm.i++;
    const old = bgm.voices; bgm.voices = [];
    if (old) old.forEach(v => { v.g.gain.cancelScheduledValues(t); v.g.gain.setValueAtTime(Math.max(v.g.gain.value, 0.0001), t); v.g.gain.exponentialRampToValueAtTime(0.0001, t + 5); v.o.forEach(o => { try { o.stop(t + 5.2); } catch (e) {} }); });
    notes.forEach((f, i) => {
      const g = ctx.createGain(), lp = ctx.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.value = 520 + i * 90; lp.Q.value = 0.7;
      const lfo = ctx.createOscillator(), lg = ctx.createGain(); lfo.frequency.value = 0.05 + i * 0.013; lg.gain.value = 160; lfo.connect(lg); lg.connect(lp.frequency); lfo.start(t);
      const o1 = ctx.createOscillator(), o2 = ctx.createOscillator(); o1.type = 'sine'; o2.type = 'triangle'; o1.frequency.value = f; o2.frequency.value = f * 1.003;
      const m2 = ctx.createGain(); m2.gain.value = 0.35; o1.connect(lp); o2.connect(m2); m2.connect(lp); lp.connect(g);
      const lvl = (i === 0 ? 0.26 : 0.24) / (1 + i * 0.15);
      g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(lvl, t + 5);
      g.connect(bgm.g); o1.start(t); o2.start(t); bgm.voices.push({ g, o: [o1, o2, lfo] });
    });
    clearTimeout(bgm.tc); bgm.tc = setTimeout(chord, 11000);
  }
  function chime() {
    if (!bgm) return;
    if (focused && A.cfg.bgm) { const n = CH[(bgm.i - 1 + CH.length) % CH.length], f = n[2 + Math.floor(Math.random() * 3)] * 2; tone(f, now(), { a: 0.01, d: 3.2, v: 0.03, wet: 0.95 }); }
    bgm.tk = setTimeout(chime, 2800 + Math.random() * 3800);
  }
  function bgmStart() {
    if (bgm || !A.cfg.bgm || !wantBgm || !AC) return; ensure(); A.unlock();
    const g = ctx.createGain(); g.gain.value = 0.0001; route(g, 0.45); bgm = { g, i: 0, voices: [], tc: 0, tk: 0 };
    chord(); bgm.tk = setTimeout(chime, 2500); fade(focused ? BGM_VOL : 0.0001, 3);
  }
  function fade(v, sec) { if (!bgm) return; const t = ctx.currentTime; bgm.g.gain.cancelScheduledValues(t); bgm.g.gain.setValueAtTime(Math.max(bgm.g.gain.value, 0.0001), t); bgm.g.gain.setTargetAtTime(v, t, sec / 3); }
  function bgmStop() {
    if (!bgm) return; const b = bgm; bgm = null; clearTimeout(b.tc); clearTimeout(b.tk);
    const t = ctx.currentTime; b.g.gain.cancelScheduledValues(t); b.g.gain.setTargetAtTime(0.0001, t, 0.3);
    setTimeout(() => { b.voices.forEach(v => v.o.forEach(o => { try { o.stop(); } catch (e) {} })); try { b.g.disconnect(); } catch (e) {} }, 1800);
  }
  A.start = function (delay) { wantBgm = true; if (delay) setTimeout(bgmStart, delay); else bgmStart(); };
  A.config = function (c) {
    Object.assign(A.cfg, c || {}); A.cfg.vol = Math.max(0, Math.min(1, +A.cfg.vol || 0));
    if (ctx) master.gain.setTargetAtTime(A.cfg.vol, ctx.currentTime, 0.1);
    if (!A.cfg.bgm) bgmStop(); else if (wantBgm) bgmStart();
  };
  A.unlock = function () { if (ctx && ctx.state === 'suspended' && ctx.resume && !(window.OfflineAudioContext && ctx instanceof window.OfflineAudioContext)) ctx.resume().catch(() => {}); };

  /* 視窗不在前景時,背景音樂淡出,以免蓋過你正在聽的音樂 */
  function setFocus(f) { focused = f; if (bgm) fade(f ? BGM_VOL : 0.0001, f ? 2 : 1); }
  addEventListener('blur', () => setFocus(false)); addEventListener('focus', () => setFocus(true));
  document.addEventListener('visibilitychange', () => setFocus(!document.hidden));
  ['pointerdown', 'keydown'].forEach(ev => addEventListener(ev, () => A.unlock(), { passive: true }));

  /* 自動綁定:滑過 / 點擊各種元件時發出對應音效 */
  A.bind = function (root) {
    const HOV = '.card,.tile,.chip,.link,.big,nav button,.seg button,.btn,.cta,.ghost,.sw';
    root.addEventListener('mouseover', e => {
      const el = e.target.closest && e.target.closest(HOV); if (!el || el === hoverEl) return; hoverEl = el;
      const t = performance.now(); if (t - lastHover > 70) { lastHover = t; A.sfx('hover'); }
    });
    root.addEventListener('mouseout', e => { if (hoverEl && !hoverEl.contains(e.relatedTarget)) hoverEl = null; });
    root.addEventListener('click', e => {
      const t = e.target.closest && e.target.closest('.sw,.tile,.card,.chip,.big,.seg button,nav button,.link,.btn');
      if (!t) return;
      if (t.matches('.sw,.tile')) setTimeout(() => A.sfx('toggle', (t.matches('.sw') ? t : t.querySelector('.sw')).classList.contains('on')), 0);
      else if (t.matches('.card,.chip,.big,.seg button')) A.sfx('select');
      else A.sfx('page');
    });
  };
  window.AM = A;
})();
