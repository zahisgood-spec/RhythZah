const { app, BrowserWindow, Tray, Menu, screen, session, ipcMain, nativeImage, desktopCapturer, shell, powerMonitor } = require('electron');
const { pathToFileURL } = require('url');
const { spawn, execFile } = require('child_process');
const os = require('os');
const path = require('path');
const fs = require('fs');
const { LyricFetcher, pick: pickCand, convertLines, setPrefTrad } = require('./lyricsrc');
const { themeOf, decide: decideGenre } = require('./genre');
const I18N = require('./i18n');
const T = s => I18N.t(s);

// 只允許開一個:再次雙擊程式時,改成打開設定視窗
if (!app.requestSingleInstanceLock()) app.exit(0);
app.on('second-instance', () => (S.onboarded ? openSettings() : openWelcome()));

// 動態桌布順暢度:不要因為被其他視窗蓋住就降低更新率
app.commandLine.appendSwitch('disable-features', 'CalculateNativeWinOcclusion');
app.commandLine.appendSwitch('disable-renderer-backgrounding');
app.commandLine.appendSwitch('disable-background-timer-throttling');
app.commandLine.appendSwitch('ignore-gpu-blocklist');
app.commandLine.appendSwitch('enable-gpu-rasterization');
// 4K:允許用顯示卡解 HEVC(H.265),很多 4K MV 是這個編碼;VP9 / AV1 / H.264 本來就支援
app.commandLine.appendSwitch('enable-features', 'PlatformHEVCDecoderSupport');
const settingsFile = () => path.join(app.getPath('userData'), 'settings-v2.json');
const logFile = () => path.join(app.getPath('userData'), 'rhythzah.log');
let S = { enabled: true, color: 'auto', size: 1, sens: 1.5, player: true, source: 'auto', lyrics: true, screens: {}, power: 'auto', fsHide: true, wall: true, wallArt: true, wallOnBattery: false, desk: true, lyricStyle: 'auto', lyricOffset: 0, lyricDesktopOnly: true, lyricScript: 'trad', lyricFx: 1 };
try { S = { ...S, ...JSON.parse(fs.readFileSync(settingsFile(), 'utf8')) }; } catch {}
if (S.lyricStyle === 'pop' && !S.styleV18) { S.lyricStyle = 'auto'; S.styleV18 = true; }   // v18: 舊設定的「大字浮現」改成自動依曲風
if (!S.v19b) { if (!S.lyricScript || S.lyricScript === 'auto') S.lyricScript = 'trad'; S.v19b = true; }   // v19.1:歌詞預設一律繁體
setPrefTrad(S.lyricScript !== 'simp' && S.lyricScript !== 'off');
if (!S.m14) { S.wallArt = true; S.m14 = true; }   // 恢復 v7 行為:找不到 MV 就用專輯封面當桌布(舊設定只轉換一次)
let wins = [], player, lyr, wall, tray, ps, desk, side;
let lastLyrics = null;
const cmdDir = path.join(os.tmpdir(), 'ibaila-cmd-' + process.pid);
let cmdSeq = 0;
let gotOutput = false;
let currentPalette = null, lastTrack = null, lastState = null, lastVol = null, lastLog = '';

const PW = 400, PH = 140;
const acrylic = (parseInt(os.release().split('.')[2]) || 0) >= 22621; // Windows 11 22H2+ 才有系統壓克力模糊
const SOURCES = [['自動(目前播放的)', 'auto'], ['Spotify', 'spotify'], ['Apple Music', 'apple'], ['YouTube Music', 'ytmusic'], ['YouTube', 'youtube']];

function log(m) {
  m = String(m); if (m === lastLog) return; lastLog = m;
  try { fs.appendFileSync(logFile(), new Date().toISOString() + ' ' + m + '\n'); } catch {}
}
// 把問題直接顯示在播放器卡片上,方便看出哪裡出錯
function diag(msg) { log('diag: ' + msg); if (player && !player.isDestroyed()) player.webContents.send('diag', msg); }
// 32 位元的 Electron 會啟動 32 位元 PowerShell(有些音訊 COM 元件在 32 位元下找不到),有 64 位元的就改用它
const PS_EXE = (() => {
  try {
    if (process.arch === 'ia32' && process.env.PROCESSOR_ARCHITEW6432) {
      const p = path.join(process.env.windir || 'C:\\Windows', 'Sysnative', 'WindowsPowerShell', 'v1.0', 'powershell.exe');
      if (fs.existsSync(p)) return p;
    }
  } catch {}
  return 'powershell.exe';
})();
log('powershell: ' + PS_EXE + ' (electron arch=' + process.arch + ')');
const everyone = () => wins.concat([player, lyr, desk, side]).filter(w => w && !w.isDestroyed());
// each screen can be switched off separately
const winSettings = w => ({ ...S, enabled: S.enabled && (S.screens || {})[w._did] !== false });
function save() {
  try { fs.writeFileSync(settingsFile(), JSON.stringify(S)); } catch {}
  everyone().forEach(w => w.webContents.send('settings', winSettings(w)));
  applyPower();
  applyVisibility();
  buildMenu();
  pushPrefs();
}
// 用小檔案把指令交給 PowerShell(不用 stdin,因為 PowerShell 5.1 讀 stdin 會卡住整個迴圈)
function sendCmd(c) {
  try { fs.mkdirSync(cmdDir, { recursive: true }); const f = path.join(cmdDir, String(++cmdSeq).padStart(8, '0')); fs.writeFileSync(f + '.part', c); fs.renameSync(f + '.part', f + '.cmd'); }   // 先寫暫存檔再改名,PowerShell 不會讀到寫一半的指令
  catch (e) { log('sendCmd failed: ' + e.message); }
}
function setSource(v) {
  S.source = v; save();
  sendCmd('source:' + v);
}
const sourceItems = () => SOURCES.map(([label, v]) => ({ label: T(label), type: 'radio', checked: S.source === v, click: () => setSource(v) }));

/* ---------- 邊緣光暈視窗 ---------- */
function makeOverlays() {
  const primary = screen.getPrimaryDisplay().id;
  screen.getAllDisplays().forEach(d => {
    const w = new BrowserWindow({
      ...d.bounds, transparent: true, frame: false, alwaysOnTop: true, skipTaskbar: true,
      focusable: false, hasShadow: false, resizable: false,
      webPreferences: { nodeIntegration: true, contextIsolation: false }
    });
    w.setAlwaysOnTop(true, 'screen-saver');
    w.setIgnoreMouseEvents(true);
    const isCapture = d.id === primary;
    w.loadFile('index.html', { query: { capture: isCapture ? '1' : '0' } });
    w.webContents.on('did-finish-load', () => {
      w.webContents.send('settings', winSettings(w));
      if (curEdge) w.webContents.send('edge-theme', curEdge);
      w.webContents.send('power', { lite: !!lastLite });
      if (currentPalette) w.webContents.send('palette', currentPalette);
      if (isCapture) w.webContents.executeJavaScript('startCapture()', true);
    });
    w._did = d.id;
    wins.push(w);
  });
}
let curEdge = null;   // 歌詞視窗最後決定的風格,螢幕邊緣光圈沿用
ipcMain.on('theme-resolved', (_, th) => { curEdge = th; wins.forEach(w => { if (!w.isDestroyed()) w.webContents.send('edge-theme', th); }); });
ipcMain.on('level', (e, data) => {
  wins.forEach(w => { if (w.webContents !== e.sender) w.webContents.send('level', data); });
  if (lyr && !lyr.isDestroyed() && lyr.isVisible()) lyr.webContents.send('level', data);
  if (side && !side.isDestroyed()) side.webContents.send('level', data);
});

/* ---------- 玻璃播放器視窗 ---------- */
function makePlayer() {
  const wa = screen.getPrimaryDisplay().workArea;
  let x = wa.x + Math.round((wa.width - PW) / 2), y = wa.y + wa.height - PH - 24;
  const p = S.pos;
  if (p && screen.getAllDisplays().some(d => p.x >= d.bounds.x - 200 && p.x < d.bounds.x + d.bounds.width - 100 && p.y >= d.bounds.y && p.y < d.bounds.y + d.bounds.height - 60)) { x = p.x; y = p.y; }
  const opts = {
    x, y, width: PW, height: PH, frame: false, alwaysOnTop: true, skipTaskbar: true, show: false,
    resizable: false, maximizable: false, fullscreenable: false, hasShadow: acrylic,
    webPreferences: { nodeIntegration: true, contextIsolation: false }
  };
  if (acrylic) { opts.backgroundMaterial = 'acrylic'; opts.backgroundColor = '#00000000'; }
  else opts.transparent = true;
  player = new BrowserWindow(opts);
  player.setAlwaysOnTop(true, 'screen-saver');
  player.loadFile('player.html', { query: { fake: acrylic ? '0' : '1' } });
  player.webContents.on('did-finish-load', () => {
    player.webContents.send('settings', S);
    if (currentPalette) player.webContents.send('palette', currentPalette);
    if (lastTrack) player.webContents.send('track', lastTrack);
    if (lastState) player.webContents.send('state', lastState);
    if (S.player && S.desk === false) player.showInactive();
  });
  player.on('moved', () => { const [px, py] = player.getPosition(); S.pos = { x: px, y: py }; save(); });
}


/* ---------- 桌面完整介面:左側時鐘+歌單、中間 Cover Flow+搜尋+播放列 ---------- */
const deskUI = () => [desk, side].filter(w => w && !w.isDestroyed());
const showUI = on => { if (S.desk !== false) deskUI().forEach(w => on ? w.showInactive() : w.hide()); else if (player && !player.isDestroyed()) on ? player.showInactive() : player.hide(); };
function makeDesk() {
  const wa = screen.getPrimaryDisplay().workArea;
  const DW = 620, DH = 140;
  const base = { frame: false, transparent: true, alwaysOnTop: true, skipTaskbar: true, show: false, hasShadow: false, resizable: false, maximizable: false, fullscreenable: false,
    webPreferences: { nodeIntegration: true, contextIsolation: false } };
  desk = new BrowserWindow({ ...base, width: DW, height: DH, x: wa.x + Math.round((wa.width - DW) / 2) + 60, y: wa.y + wa.height - DH - 30 });
  deskBase = desk.getBounds();
  desk.on('moved', () => { if (!deskOpen) deskBase = desk.getBounds(); });
  side = new BrowserWindow({ ...base, width: 340, height: 44, x: wa.x + 28, y: wa.y + 24, focusable: false });
  side.setIgnoreMouseEvents(false);
  [desk, side].forEach(w => {
    w.setAlwaysOnTop(true, 'screen-saver');
    w.webContents.on('did-finish-load', () => {
      w.webContents.send('settings', S);
      if (currentPalette) w.webContents.send('palette', currentPalette);
      if (lastTrack) w.webContents.send('track', lastTrack);
      if (lastState) w.webContents.send('state', lastState);
      if (lastVol) w.webContents.send('volume', lastVol);
      if (artistData) w.webContents.send('artist', artistData);
      if (S.player) w.showInactive();
    });
  });
  desk.loadFile('desk.html'); side.loadFile('side.html');
}
// iTunes 公開搜尋 API(不用金鑰):歌手的專輯與歌曲
let artistData = null, artistFor = '', deskBase = null, deskOpen = false;
const art = (u, n) => String(u || '').replace(/\/\d+x\d+(bb)?\.(jpg|png)/, `/${n}x${n}bb.$2`);
async function itunes(params) {
  const r = await fetch('https://itunes.apple.com/search?' + new URLSearchParams({ limit: '25', ...params }), { headers: { 'User-Agent': UA } });
  if (!r.ok) throw new Error('itunes ' + r.status);
  return (await r.json()).results || [];
}
const albumItem = x => ({ kind: 'album', name: x.collectionName, sub: `${String(x.releaseDate || '').slice(0, 4)} · Album`, art: art(x.artworkUrl100, 300), artist: x.artistName, url: x.collectionViewUrl });
const songItem = x => ({ kind: 'song', name: x.trackName, sub: x.artistName, art: art(x.artworkUrl100, 100), artist: x.artistName, url: x.trackViewUrl });
async function loadArtist(t) {
  const a = firstArtist(t && t.artist);
  if (!a || a === artistFor) return;
  artistFor = a;
  try {
    const songs = await itunes({ term: a, entity: 'song', attribute: 'artistTerm', limit: '18' });
    if (artistFor !== a) return;
    artistData = { artist: a, songs: songs.filter(x => x.trackName).map(songItem) };
    deskUI().forEach(w => w.webContents.send('artist', artistData));
  } catch (e) { log('artist lookup failed: ' + e.message); }
}
ipcMain.on('desk-expand', (_, on) => {
  if (!desk || desk.isDestroyed() || !deskBase) return;
  deskOpen = !!on;
  const extra = on ? 270 : 0;
  desk.setBounds({ x: deskBase.x, y: deskBase.y - extra, width: deskBase.width, height: deskBase.height + extra });
});
ipcMain.on('toggle-wall', () => { S.wall = !S.wall; if (S.wall && !wall) makeWallpaper(); save(); });
ipcMain.on('search', async (_, q) => {
  try {
    const rs = await itunes({ term: String(q).slice(0, 80), entity: 'song', limit: '15' });
    if (desk && !desk.isDestroyed()) desk.webContents.send('search-result', { results: rs.filter(x => x.trackName).map(songItem) });
  } catch (e) { log('search failed: ' + e.message); if (desk && !desk.isDestroyed()) desk.webContents.send('search-result', { results: [] }); }
});
// 點專輯/歌曲:在目前選的來源裡打開(Spotify / YouTube Music 用搜尋,Apple Music 直接開連結)
ipcMain.on('open-item', (_, it) => {
  if (!it || typeof it.name !== 'string') return;
  const q = encodeURIComponent(`${it.artist || ''} ${it.name}`.trim());
  const src = S.source === 'auto' ? ((lastTrack && lastTrack.app) || '') : S.source;
  let url;
  if (/spotify/i.test(src)) url = 'spotify:search:' + q;
  else if (/yt|youtube/i.test(src)) url = 'https://music.youtube.com/search?q=' + q;
  else if (/^https:\/\/(music|itunes)\.apple\.com\//.test(it.url || '')) url = it.url;
  else url = 'https://music.youtube.com/search?q=' + q;
  shell.openExternal(url).catch(e => log('open failed: ' + e.message));
});
ipcMain.on('toggle-lyrics', () => { S.lyrics = !S.lyrics; save(); });

/* ---------- 省電(電池 / 全螢幕)---------- */
let onBattery = false, lastLite = null, yielding = false, fsTimer = null;
const fsFlips = [];
const isLite = () => S.power === 'on' || (S.power !== 'off' && onBattery);
function applyPower() {
  const lite = isLite();
  if (lite === lastLite) return;
  lastLite = lite;
  log('power: lite=' + lite + ' battery=' + onBattery);
  wins.forEach(w => { if (!w.isDestroyed()) w.webContents.send('power', { lite }); });
  sendCmd('rate:' + (lite ? 'slow' : 'fast'));
  updateWallpaper();
}
// something else went full screen (a game, a video): step aside until it is over
function onFs(q) {
  clearTimeout(fsTimer);
  const full = q === 2 || q === 3 || q === 4;
  if (full === yielding) return;
  fsTimer = setTimeout(() => {
    yielding = full;
    const now = Date.now(); fsFlips.push(now);
    while (fsFlips.length && now - fsFlips[0] > 30000) fsFlips.shift();
    if (fsFlips.length >= 6) {   // flipping back and forth: our own windows are probably what is being detected
      S.fsHide = false; yielding = false; log('fullscreen detection keeps flipping, turned off'); diag('全螢幕偵測不穩定,已自動關閉'); save(); return;
    }
    log('fullscreen=' + full + ' (state ' + q + ')');
    applyVisibility();
  }, full ? 1200 : 400);
}
/* ---------- 歌詞只顯示在桌面:有視窗蓋到歌詞區域時就先藏起來 ---------- */
let lastWins = [], winsAware = false, lastCovered = false;
function lyrCovered() {
  if (!S.lyricDesktopOnly || !lyr || lyr.isDestroyed() || !lastWins.length) return false;
  let b = lyr.getBounds();
  if (winsAware) { try { b = screen.dipToScreenRect(null, b); } catch {} }
  const mg = 8;   // 留一點邊,邊緣擦到不算
  return lastWins.some(([l, t, r, bt]) => l < b.x + b.width - mg && r > b.x + mg && t < b.y + b.height - mg && bt > b.y + mg);
}
function onWins(d) {
  winsAware = !!d.aware;
  lastWins = String(d.r || '').split(';').filter(Boolean).map(s => s.split(',').map(Number));
  const c = lyrCovered();
  if (c !== lastCovered) { lastCovered = c; setLyrShown(); }   // 只動歌詞視窗,不跑整套 applyVisibility,藏起來才快
}
function setLyrShown() {
  if (!lyr || lyr.isDestroyed()) return;
  const y = yielding && S.fsHide;
  (S.lyrics && lastLyrics && !y && !lyrCovered()) ? lyr.showInactive() : lyr.hide();
}
function syncDesktopOnly() { sendCmd('wins:' + (S.lyricDesktopOnly ? 'on' : 'off')); if (!S.lyricDesktopOnly) { lastWins = []; lastCovered = false; } }
function applyVisibility() {
  const y = yielding && S.fsHide;
  wins.forEach(w => { if (!w.isDestroyed()) y ? w.hide() : w.showInactive(); });
  if (S.desk !== false) { if (player && !player.isDestroyed()) player.hide(); deskUI().forEach(w => (S.player && !y) ? w.showInactive() : w.hide()); }
  else { deskUI().forEach(w => w.hide()); if (player && !player.isDestroyed()) (S.player && !y) ? player.showInactive() : player.hide(); }
  if (lyr && !lyr.isDestroyed()) (S.lyrics && lastLyrics && !y && !lyrCovered()) ? lyr.showInactive() : lyr.hide();
  updateWallpaper();
}

/* ---------- 動態桌布(動態封面 / MV)---------- */
// A window that is glued to the desktop layer (behind the icons). The song's moving artwork or video plays in it.
let wallAttached = false, wallMedia = null;
const badWall = new Set();
const wallDir = () => path.join(app.getPath('userData'), 'wallpapers');
const WALL_PS = String.raw`param([long]$Hwnd, [int]$X, [int]$Y, [int]$W, [int]$H)
Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;
public static class IbWall {
  public delegate bool EnumProc(IntPtr h, IntPtr l);
  [DllImport("user32.dll")] public static extern bool SetProcessDPIAware();
  [DllImport("user32.dll")] public static extern IntPtr FindWindow(string c, string t);
  [DllImport("user32.dll")] public static extern IntPtr FindWindowEx(IntPtr p, IntPtr a, string c, string t);
  [DllImport("user32.dll")] public static extern bool EnumWindows(EnumProc cb, IntPtr l);
  [DllImport("user32.dll")] public static extern IntPtr SendMessageTimeout(IntPtr h, uint m, IntPtr w, IntPtr l, uint f, uint t, out IntPtr r);
  [DllImport("user32.dll")] public static extern IntPtr SetParent(IntPtr c, IntPtr p);
  [DllImport("user32.dll")] public static extern bool MoveWindow(IntPtr h, int x, int y, int w, int hh, bool r);
  [DllImport("user32.dll")] public static extern bool SetWindowPos(IntPtr h, IntPtr after, int x, int y, int w, int hh, uint f);
  public static string Attach(long hwnd, int x, int y, int w, int h) {
    SetProcessDPIAware();
    IntPtr prog = FindWindow("Progman", null);
    if (prog == IntPtr.Zero) return "FAIL no Progman";
    IntPtr res;
    SendMessageTimeout(prog, 0x052C, IntPtr.Zero, IntPtr.Zero, 0, 1000, out res);
    IntPtr worker = IntPtr.Zero;
    EnumWindows(delegate(IntPtr top, IntPtr l) {
      IntPtr shell = FindWindowEx(top, IntPtr.Zero, "SHELLDLL_DefView", null);
      if (shell != IntPtr.Zero) { worker = FindWindowEx(IntPtr.Zero, top, "WorkerW", null); }
      return true;
    }, IntPtr.Zero);
    IntPtr me = new IntPtr(hwnd);
    if (worker != IntPtr.Zero) {
      SetParent(me, worker); MoveWindow(me, x, y, w, h, true);
      return "OK classic";
    }
    // Windows 11 24H2 layout: the icon layer lives inside Progman itself
    IntPtr def = FindWindowEx(prog, IntPtr.Zero, "SHELLDLL_DefView", null);
    if (def != IntPtr.Zero) {
      SetParent(me, prog);
      SetWindowPos(me, def, x, y, w, h, 0x0010);
      return "OK below-icons";
    }
    IntPtr wk = FindWindowEx(prog, IntPtr.Zero, "WorkerW", null);
    if (wk != IntPtr.Zero) { SetParent(me, wk); MoveWindow(me, x, y, w, h, true); return "OK progman-workerw"; }
    return "FAIL no desktop layer found";
  }
}
'@
try { Write-Output ([IbWall]::Attach($Hwnd, $X, $Y, $W, $H)) } catch { Write-Output ('FAIL ' + $_.Exception.Message) }
`;
function makeWallpaper() {
  const d = screen.getPrimaryDisplay();
  wall = new BrowserWindow({
    ...d.bounds, frame: false, show: false, skipTaskbar: true, focusable: false, hasShadow: false, resizable: false, backgroundColor: '#000000',
    webPreferences: { nodeIntegration: true, contextIsolation: false, backgroundThrottling: false }
  });
  wall.setIgnoreMouseEvents(true);
  wall.loadFile('wallpaper.html');
  wall.webContents.on('did-finish-load', attachWallpaper);
}
function attachWallpaper() {
  if (!wall || wall.isDestroyed()) return;
  try {
    const rect = r => screen.dipToScreenRect(null, r);
    const all = screen.getAllDisplays().map(x => rect(x.bounds));
    const minX = Math.min(...all.map(r => r.x)), minY = Math.min(...all.map(r => r.y));
    const r = rect(screen.getPrimaryDisplay().bounds);
    const hb = wall.getNativeWindowHandle();
    const hwnd = hb.length >= 8 ? hb.readBigUInt64LE(0).toString() : String(hb.readUInt32LE(0));
    const f = path.join(os.tmpdir(), 'ibaila-wall-' + process.pid + '.ps1');
    fs.writeFileSync(f, '\uFEFF' + WALL_PS, 'utf8');
    const p = spawn(PS_EXE, ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-File', f,
      '-Hwnd', hwnd, '-X', String(r.x - minX), '-Y', String(r.y - minY), '-W', String(r.width), '-H', String(r.height)], { windowsHide: true });
    let out = '';
    p.stdout.on('data', c => out += c); p.stderr.on('data', c => out += c);
    p.on('exit', () => {
      try { fs.rmSync(f, { force: true }); } catch {}
      out = out.trim().replace(/\s+/g, ' '); log('wallpaper attach: ' + out);
      if (/^OK/.test(out)) { wallAttached = true; updateWallpaper(); }
      else diag('動態桌布無法接上桌面: ' + out.slice(0, 70));
    });
    p.on('error', e => log('wallpaper attach error: ' + e.message));
  } catch (e) { log('wallpaper attach failed: ' + e.message); }
}
const artMedia = t => ({ kind: 'art', src: t.cover || '' });
function refreshArt() { if (wallMedia && wallMedia.kind === 'art' && lastTrack) { wallMedia = artMedia(lastTrack); updateWallpaper(); } }
function wallVisible() {
  return !!(S.wall && wallAttached && wallMedia && !(wallMedia.kind === 'art' && !wallMedia.src) && lastState && lastState.playing && !(yielding && S.fsHide) && !(isLite() && !S.wallOnBattery));
}
let wallHideTimer = null;
function hideWallpaper() {
  if (!wall || wall.isDestroyed()) return;
  wall.webContents.send('wall', null);
  setTimeout(() => { if (wall && !wall.isDestroyed() && !wallVisible()) wall.hide(); }, 1000);
}
function updateWallpaper() {
  if (!wall || wall.isDestroyed()) return;
  if (wallVisible()) { clearTimeout(wallHideTimer); wallHideTimer = null; wall.webContents.send('wall', wallMedia); if (!wall.isVisible()) wall.showInactive(); return; }
  // 暫停:跟 v7 一樣收掉桌布,只多等 1.2 秒,避免狀態抖一下就把影片卸載又重載
  const pausedOnly = S.wall && wallAttached && wallMedia && lastState && !lastState.none && !lastState.playing && !(yielding && S.fsHide) && !(isLite() && !S.wallOnBattery);
  if (pausedOnly) { if (!wallHideTimer) wallHideTimer = setTimeout(() => { wallHideTimer = null; if (!wallVisible()) hideWallpaper(); }, 1200); return; }
  clearTimeout(wallHideTimer); wallHideTimer = null; hideWallpaper();
}
const norm = s => String(s || '').toLowerCase().replace(/[^\p{L}\p{N}]+/gu, '');
// 1) your own clips: put "Artist - Song.mp4" in the wallpapers folder
function localWallpaper(track) {
  let files = [];
  try { files = fs.readdirSync(wallDir()).filter(f => /\.(mp4|webm|m4v|mov)$/i.test(f)); } catch { return null; }
  const t = norm(cleanTitle(track.title)), a = norm(firstArtist(track.artist));
  if (t.length < 2) return null;
  let best = null, score = 0;
  for (const f of files) {
    const n = norm(f.replace(/\.[^.]+$/, ''));
    if (!n.includes(t)) continue;
    const sc = 1 + (a && n.includes(a) ? 2 : 0);
    if (sc > score) { best = f; score = sc; }
  }
  return best ? { src: pathToFileURL(path.join(wallDir(), best)).href, kind: 'file' } : null;
}

// 1.5) 官方 MV 預覽片段(iTunes 公開搜尋的 musicVideo,約 30 秒,循環播放;整支 MV 請放進自訂資料夾)
const mvCache = new Map();
// 先把預覽片下載到本機再播(邊下邊播和循環接縫會卡),最多保留 30 個
const mvDir = () => path.join(app.getPath('userData'), 'mvcache');
async function cacheVideo(url) {
  try {
    fs.mkdirSync(mvDir(), { recursive: true });
    const name = require('crypto').createHash('md5').update(url).digest('hex') + '.mp4';
    const f = path.join(mvDir(), name);
    if (!fs.existsSync(f) || fs.statSync(f).size < 50000) {
      const r = await fetch(url, { headers: { 'User-Agent': UA } });
      if (!r.ok) throw new Error('http ' + r.status);
      fs.writeFileSync(f, Buffer.from(await r.arrayBuffer()));
      const all = fs.readdirSync(mvDir()).map(n => [n, fs.statSync(path.join(mvDir(), n)).mtimeMs]).sort((a, b) => b[1] - a[1]);
      all.slice(30).forEach(([n]) => { try { fs.rmSync(path.join(mvDir(), n), { force: true }); } catch {} });
    }
    return pathToFileURL(f).href;
  } catch (e) { log('mv cache failed: ' + e.message); return url; }
}

async function musicVideo(track) {
  const t = cleanTitle(track.title), a = firstArtist(track.artist), key = a + '|' + t;
  if (mvCache.has(key)) return mvCache.get(key);
  let out = null;
  try {
    const res = await itunes({ term: `${a} ${t}`.trim(), entity: 'musicVideo', limit: '8' });
    const nt = norm(t), na = norm(a);
    const hit = res.find(x => x.previewUrl && norm(cleanTitle(x.trackName)) === nt && (!na || norm(x.artistName).includes(na) || na.includes(norm(x.artistName))))
      || res.find(x => x.previewUrl && nt.length > 3 && norm(x.trackName).includes(nt) && (!na || norm(x.artistName).includes(na)));
    if (hit) out = { src: await cacheVideo(hit.previewUrl), kind: 'preview' };
  } catch (e) { log('music video lookup failed: ' + e.message); }
  mvCache.set(key, out);
  return out;
}
// 2) Apple Music animated artwork, found through the song's album page (best effort: not every album has it)
const motionCache = new Map();
const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0 Safari/537.36';
function findMotion(html) {
  const un = s => s.replace(/\\u002F/gi, '/').replace(/\\\//g, '/').replace(/&amp;/g, '&');
  const m = html.match(/<script[^>]*id="serialized-server-data"[^>]*>([\s\S]*?)<\/script>/);
  if (m) {
    try {
      const found = [];
      const walk = (o, key, inEd) => {
        if (!o || typeof o !== 'object') { if (inEd && typeof o === 'string' && /\.m3u8/.test(o)) found.push([key, o]); return; }
        for (const k of Object.keys(o)) walk(o[k], k, inEd || k === 'editorialVideo');
      };
      walk(JSON.parse(m[1]), '', false);
      if (found.length) { const sq = found.find(([k]) => /square|1x1/i.test(k)) || found[0]; return un(sq[1]); }
    } catch {}
  }
  const i = html.indexOf('editorialVideo');
  if (i >= 0) { const r = un(html.slice(i, i + 8000)).match(/https:[^"'\\\s]+?\.m3u8[^"'\\\s]*/); if (r) return r[0]; }
  return null;
}
async function appleMotion(track) {
  const t = cleanTitle(track.title), a = firstArtist(track.artist), key = a + '|' + t;
  if (motionCache.has(key)) return motionCache.get(key);
  let src = null;
  try {
    const r = await fetch('https://itunes.apple.com/search?' + new URLSearchParams({ term: `${a} ${t}`.trim(), entity: 'song', limit: '5' }));
    const res = (await r.json()).results || [];
    const hit = res.find(x => x.trackName && t && x.trackName.toLowerCase().includes(t.toLowerCase().slice(0, 12))) || res[0];
    if (hit && hit.collectionViewUrl) {
      const html = await (await fetch(hit.collectionViewUrl.split('?')[0], { headers: { 'User-Agent': UA, 'Accept-Language': 'en-US,en;q=0.9' } })).text();
      src = findMotion(html);
    }
  } catch (e) { log('motion artwork lookup failed: ' + e.message); }
  const out = src ? { src, kind: 'hls' } : null;
  motionCache.set(key, out);
  return out;
}
function loadWallpaper(track) {
  wallMedia = null; updateWallpaper();
  if (!S.wall || !(track.title || track.artist)) return;
  (async () => {
    let m = localWallpaper(track);
    if (!m) m = await musicVideo(track);
    if (!m) m = await appleMotion(track);
    if (lastTrack !== track) return;
    if (!m || badWall.has(m.src)) {
      log('no moving artwork for this song' + (S.wallArt ? ', using the album cover' : ''));
      if (S.wallArt) { wallMedia = artMedia(track); updateWallpaper(); }
      return;
    }
    log('wallpaper: ' + m.kind + ' ' + m.src.slice(0, 90));
    wallMedia = m; updateWallpaper();
  })().catch(e => log('wallpaper error: ' + e.message));
}
ipcMain.on('wall-failed', (_, src) => { badWall.add(src); wallMedia = (S.wallArt && lastTrack) ? artMedia(lastTrack) : null; updateWallpaper(); diag('這首歌的動態桌布無法播放'); });

/* ---------- 同步歌詞(LRCLIB,免費、不用金鑰)---------- */
function makeLyrics() {
  const wa = screen.getPrimaryDisplay().workArea;
  const LW = Math.min(1100, wa.width - 80), LH = 380;
  lyr = new BrowserWindow({
    x: wa.x + Math.round((wa.width - LW) / 2), y: Math.round(wa.y + wa.height * 0.60 - LH / 2), width: LW, height: LH,
    transparent: true, frame: false, alwaysOnTop: true, skipTaskbar: true, focusable: false, hasShadow: false, resizable: false, show: false,
    webPreferences: { nodeIntegration: true, contextIsolation: false }
  });
  lyr.setAlwaysOnTop(true, 'screen-saver');
  lyr.setIgnoreMouseEvents(true);
  lyr.loadFile('lyrics.html');
  lyr.webContents.on('did-finish-load', () => {
    lyr.webContents.send('settings', S);
    if (currentPalette) lyr.webContents.send('palette', currentPalette);
    if (lastTrack) lyr.webContents.send('track', lastTrack);
    if (lastState) lyr.webContents.send('state', lastState);
    if (lastLyrics) lyr.webContents.send('lyrics', lastLyrics);
    if (curTheme) lyr.webContents.send('theme', { theme: curTheme, genre: curGenre });
  });
}
let fetcher = null, curWant = null, curCands = null, curBest = null, curDur = 0;
const getFetcher = () => fetcher || (fetcher = new LyricFetcher({ cacheFile: path.join(app.getPath('userData'), 'lyrics-cache-v19.json'), log }));
function showLyrics(l) {
  lastLyrics = l;
  if (lyr && !lyr.isDestroyed()) lyr.webContents.send('lyrics', l);
  applyVisibility();
}
// 挑出目前最好的版本並顯示(曲長、設定改變時也會重挑)
function chooseLyrics(why) {
  if (!curCands || !curWant) return;
  const dur = curDur, best = pickCand(curCands, curWant, dur);
  if (!best || !best.lines.length) return;
  if (best === curBest && why !== 'force') return;
  curBest = best;
  const lines = convertLines(best.lines, S.lyricScript || 'auto', curWant);
  log(`lyrics: ${best.est ? 'ESTIMATED timing' : lines.length + ' lines'} from ${best.src} (score ${(best.score || 0).toFixed(2)}${dur ? ', dur ' + Math.round(dur) + 's' : ''}${lines.some(x => x.ct) ? ', word-timed' : ''}) ${why || ''}`);
  showLyrics(lines);
}
function loadLyrics(track, force) {
  showLyrics(null); curCands = null; curBest = null; curWant = null; curDur = 0; lastRepickDur = 0; sendTheme(null, '');
  if (!track.title) return;
  const f = getFetcher(), want = { title: track.title, artist: track.artist, dur: 0 };
  if (force) f.forget({ title: track.title, artist: track.artist });
  f.fetch(want, partial => {          // 最快的來源一回來就先顯示,後面來了更好的再換
    if (lastTrack !== track) return;
    curWant = { rawTitle: want.title, title: cleanTitle(want.title), artist: firstArtist(want.artist) }; curCands = partial; chooseLyrics('(first result)');
  }).then(r => {
    if (lastTrack !== track) return;
    curWant = r.w; curCands = r.cands;
    if (!r.cands.length) { log('no lyrics found from any source'); return; }
    chooseLyrics(r.cached ? '(cache)' : '(final)');
  }).catch(e => log('lyrics failed: ' + e.message));
  loadGenre(track);
}
// 歌曲長度晚一點才知道時,重新挑一次最吻合的版本
let lastRepickDur = 0;
function repickLyrics(dur) {
  if (!curCands || !(dur > 0) || Math.abs(dur - lastRepickDur) < 1) return;
  lastRepickDur = dur; chooseLyrics('(duration ' + Math.round(dur) + 's)');
}

/* ---------- 曲風 → 歌詞風格 ---------- */
const genreCache = new Map();
let curTheme = null, curGenre = '';
function sendTheme(theme, genre) {
  curTheme = theme; curGenre = genre;
  if (lyr && !lyr.isDestroyed()) lyr.webContents.send('theme', { theme, genre });
}
// 曲風:iTunes 多國商店投票(曲風名稱各國語言不同)+ 歌手代表作 + 歌名線索,具體風格勝過泛稱的 pop
async function lookupGenre(rawTitle, t, a) {
  const { sim } = require('./lyricsrc'), votes = [], term = (a + ' ' + t).trim();
  const stores = [{}, { country: 'TW' }, { country: 'JP' }, { country: 'KR' }, { country: 'US' }];
  const rs = await Promise.all(stores.map(o => itunes({ term, entity: 'song', limit: '10', ...o }).catch(() => [])));
  rs.forEach((list, i) => list.forEach(x => {
    const ts = Math.max(sim(cleanTitle(x.trackName), t), sim(x.trackName, rawTitle)), as = a ? sim(x.artistName, a) : .5;
    if (ts >= .9 && x.primaryGenreName) votes.push({ g: x.primaryGenreName, w: as >= .5 ? (i === 0 ? 1.2 : 1) : .4 });
  }));
  if (!votes.length && a) {   // 查不到這首:看這位歌手其他歌的曲風
    const lists = await Promise.all([{}, { country: 'TW' }].map(o => itunes({ term: a, entity: 'song', attribute: 'artistTerm', limit: '25', ...o }).catch(() => [])));
    lists.forEach(list => list.forEach(x => { if (x.primaryGenreName && sim(x.artistName, a) >= .6) votes.push({ g: x.primaryGenreName, w: .12 }); }));
  }
  return decideGenre(votes, rawTitle);
}
async function loadGenre(track) {
  const t = cleanTitle(track.title), a = firstArtist(track.artist), key = a + '|' + t;
  let info = genreCache.get(key);
  if (info === undefined) {
    info = { theme: null, genre: '' };
    try { info = await lookupGenre(track.title, t, a); } catch (e) { log('genre lookup failed: ' + e.message); }
    if (info.theme || info.genre) genreCache.set(key, info);
  }
  if (lastTrack !== track) return;
  log('genre: ' + (info.genre || '(unknown)') + ' -> ' + (info.theme || 'auto-detect from lyrics'));
  sendTheme(info.theme, info.genre);
}
/* ---------- 設定視窗(所有選項都在這裡,不用再右鍵托盤)---------- */
let setWin = null;
function prefsPayload() {
  return {
    S, version: app.getVersion(), autostart: app.getLoginItemSettings().openAtLogin,
    displays: screen.getAllDisplays().map((d, i) => ({ id: d.id, on: (S.screens || {})[d.id] !== false, label: `螢幕 ${i + 1}${d.id === screen.getPrimaryDisplay().id ? '(主要)' : ''}  ${d.size.width}×${d.size.height}` }))
  };
}
function pushPrefs() { if (setWin && !setWin.isDestroyed()) setWin.webContents.send('prefs', prefsPayload()); }
function openSettings(o) {
  o = o || {};
  if (setWin && !setWin.isDestroyed()) {
    if (setWin.isMinimized()) setWin.restore(); setWin.show(); setWin.focus();
    if (o.tab) setWin.webContents.send('goto', o.tab, o.from);
    return setWin;
  }
  // 和歡迎視窗同樣大小、同樣位置、同樣的標題列,從歡迎視窗跳過來時看起來像同一個視窗在換頁
  const b = o.bounds || {};
  setWin = new BrowserWindow({
    width: b.width || 940, height: b.height || 660, x: b.x, y: b.y, minWidth: 820, minHeight: 600,
    title: T('RhythZah 設定'), backgroundColor: '#000000', icon: path.join(__dirname, 'icon.png'),
    autoHideMenuBar: true, titleBarStyle: 'hidden', titleBarOverlay: { color: '#00000000', symbolColor: '#ffffff', height: 38 },
    show: !o.from, webPreferences: { nodeIntegration: true, contextIsolation: false, autoplayPolicy: 'no-user-gesture-required' }
  });
  setWin.setMenuBarVisibility(false);
  const q = {}; if (o.tab) q.tab = o.tab; if (o.from) q.from = o.from;
  setWin.loadFile('settings.html', { query: q });
  if (o.from) setWin.once('ready-to-show', () => { setWin.show(); setWin.focus(); setTimeout(closeWelcome, 250); });   // 設定視窗畫好才關掉歡迎視窗
  setWin.on('closed', () => { setWin = null; });
  return setWin;
}
/* ---------- 首次啟動引導視窗:問要連結哪個軟體、要不要開機自動啟動 ---------- */
let welWin = null;
function openWelcome() {
  if (welWin && !welWin.isDestroyed()) { if (welWin.isMinimized()) welWin.restore(); welWin.show(); welWin.focus(); return; }
  welWin = new BrowserWindow({
    width: 940, height: 660, minWidth: 820, minHeight: 600, title: T('歡迎使用 RhythZah'), backgroundColor: '#000000', icon: path.join(__dirname, 'icon.png'),
    autoHideMenuBar: true, titleBarStyle: 'hidden', titleBarOverlay: { color: '#00000000', symbolColor: '#ffffff', height: 38 },
    webPreferences: { nodeIntegration: true, contextIsolation: false, autoplayPolicy: 'no-user-gesture-required' }
  });
  welWin.setMenuBarVisibility(false);
  welWin.loadFile('welcome.html');
  welWin.on('closed', () => { welWin = null; });
}
function closeWelcome() { if (welWin && !welWin.isDestroyed()) welWin.close(); }
// 看看哪些音樂軟體正在執行,在引導視窗的卡片上標示「執行中」
ipcMain.handle('onboard:detect', () => new Promise(resolve => {
  try {
    execFile('tasklist', ['/fo', 'csv', '/nh'], { windowsHide: true, timeout: 5000, maxBuffer: 8 * 1024 * 1024 }, (err, out) => {
      if (err) return resolve(null);
      const t = String(out).toLowerCase();
      resolve({
        spotify: t.includes('"spotify.exe"'),
        apple: t.includes('"applemusic.exe"') || t.includes('"itunes.exe"'),
        browser: ['"chrome.exe"', '"msedge.exe"', '"firefox.exe"', '"brave.exe"', '"opera.exe"'].some(n => t.includes(n))
      });
    });
  } catch { resolve(null); }
}));
ipcMain.on('onboard:done', (_, o) => {
  o = o || {};
  if (SOURCES.some(x => x[1] === o.source)) setSource(o.source);
  try { app.setLoginItemSettings({ openAtLogin: !!o.autostart }); } catch (e) { log('autostart failed: ' + e.message); }
  S.onboarded = true; save();
  // 設定完成 → 直接跳到設定視窗的首頁(沿用歡迎視窗的位置與大小)
  const bounds = welWin && !welWin.isDestroyed() ? welWin.getBounds() : null;
  if (setWin && !setWin.isDestroyed()) { openSettings({ tab: 'home', from: 'welcome' }); closeWelcome(); }
  else openSettings({ tab: 'home', from: 'welcome', bounds });
});
ipcMain.on('onboard:skip', () => { S.onboarded = true; save(); closeWelcome(); });

const PREF_KEYS = new Set(['enabled', 'edgeTheme', 'color', 'size', 'sens', 'lyrics', 'lyricStyle', 'lyricFx', 'lyricScript', 'lyricOffset', 'lyricDesktopOnly', 'player', 'desk', 'wall', 'wallArt', 'wallOnBattery', 'power', 'fsHide', 'uiSfx', 'uiBgm', 'uiVol']);
function setPref(k, v) {
  if (typeof k !== 'string') return;
  if (k.startsWith('screen:')) { S.screens = { ...(S.screens || {}), [k.slice(7)]: !!v }; save(); return; }
  if (k === 'autostart') { app.setLoginItemSettings({ openAtLogin: !!v }); pushPrefs(); return; }
  if (k === 'source') { if (SOURCES.some(x => x[1] === v)) setSource(v); return; }
  if (k === 'lang') {
    if (!I18N.LANGS.some(x => x[0] === v)) return;
    S.lang = v; I18N.setLang(v); save();
    BrowserWindow.getAllWindows().forEach(w => { try { w.webContents.send('lang', v); } catch {} });   // 視窗標題跟著頁面 <title> 自動換
    return;
  }
  if (!PREF_KEYS.has(k)) return;
  S[k] = v;
  if (k === 'lyricScript') setPrefTrad(v === 'trad');
  if (k === 'wall' && v && !wall) makeWallpaper();
  save();
  if (k === 'lyricScript') chooseLyrics('force');
  if (k === 'wallArt' && lastTrack) loadWallpaper(lastTrack);
  if (k === 'lyricDesktopOnly') syncDesktopOnly();
}
function doAction(a) {
  if (a === 'refetch') { if (lastTrack) { log('lyrics: manual refetch'); loadLyrics(lastTrack, true); } }
  else if (a === 'wallfolder') { try { fs.mkdirSync(wallDir(), { recursive: true }); } catch {} shell.openPath(wallDir()); }
  else if (a === 'rewall') { wallAttached = false; attachWallpaper(); }
  else if (a === 'log') shell.openPath(logFile());
  else if (a === 'restart') restartReader();
  else if (a === 'welcome') openWelcome();
  else if (a === 'quit') app.quit();
}
ipcMain.on('lang:get', e => { e.returnValue = S.lang || I18N.detect(app.getLocale()); });
ipcMain.handle('prefs:get', () => prefsPayload());
ipcMain.on('prefs:set', (_, k, v) => setPref(k, v));
ipcMain.on('prefs:act', (_, a) => doAction(a));

/* 托盤圖示換成目前的專輯封面 */
const defaultTrayIcon = () => nativeImage.createFromPath(path.join(__dirname, 'icon-32.png'));
function setTrayCover(cover) {
  try { if (tray) tray.setImage(cover ? nativeImage.createFromDataURL(cover).resize({ width: 32, height: 32 }) : defaultTrayIcon()); } catch (e) { log('tray icon failed: ' + e.message); }
}
ipcMain.on('ctl', (_, cmd) => {
  if (/^(toggle|next|prev|mute:toggle|vol:\d{1,3}|seek:\d+(\.\d+)?)$/.test(cmd)) sendCmd(cmd);
});
ipcMain.on('pick-source', () => Menu.buildFromTemplate(sourceItems()).popup({ window: player }));
ipcMain.on('log', (_, m) => log('player: ' + m));
// 封面顏色由播放器視窗用 Chromium 解碼後算出來,再統一廣播
ipcMain.on('palette', (_, pal) => { currentPalette = pal; everyone().forEach(w => w.webContents.send('palette', pal)); });

/* ---------- 讀取目前播放的歌 ---------- */
function mimeOf(b) {
  if (b[0] === 0xFF && b[1] === 0xD8) return 'image/jpeg';
  if (b[0] === 0x89 && b[1] === 0x50) return 'image/png';
  if (b[0] === 0x47 && b[1] === 0x49) return 'image/gif';
  if (b[0] === 0x42 && b[1] === 0x4D) return 'image/bmp';
  if (b.slice(0, 4).toString() === 'RIFF' && b.slice(8, 12).toString() === 'WEBP') return 'image/webp';
  return 'image/jpeg';
}
/* ---------- 封面備援:系統沒給封面時,用歌名+歌手上網找 ---------- */
const coverCache = new Map();
const cleanTitle = t => String(t || '').replace(/[\(\[（【].*?[\)\]）】]/g, ' ').replace(/\s[-–—|]\s.*$/, ' ').replace(/\b(feat|ft)\.?.*$/i, ' ').replace(/\s+/g, ' ').trim();
const firstArtist = a => String(a || '').split(/,|&|;|×|\bfeat\b|\bft\b/i)[0].replace(/VEVO$/i, '').trim();
async function fetchCover(title, artist) {
  const t = cleanTitle(title), a = firstArtist(artist), key = a + '|' + t;
  if (coverCache.has(key)) return coverCache.get(key);
  let url = null;
  try {
    const r = await fetch('https://itunes.apple.com/search?' + new URLSearchParams({ term: `${a} ${t}`.trim(), entity: 'song', limit: '5' }));
    const res = (await r.json()).results || [];
    const hit = res.find(x => x.trackName && t && x.trackName.toLowerCase().includes(t.toLowerCase().slice(0, 12))) || res[0];
    if (hit && hit.artworkUrl100) url = hit.artworkUrl100.replace(/\d+x\d+bb/, '600x600bb');
  } catch (e) { log('itunes search failed: ' + e.message); }
  if (!url) {
    try {
      const r = await fetch('https://api.deezer.com/search?limit=1&q=' + encodeURIComponent(`artist:"${a}" track:"${t}"`));
      const d = ((await r.json()).data || [])[0];
      if (d && d.album) url = d.album.cover_xl || d.album.cover_big;
    } catch (e) { log('deezer search failed: ' + e.message); }
  }
  let data = null;
  if (url) {
    try {
      const b = Buffer.from(await (await fetch(url)).arrayBuffer());
      data = `data:${mimeOf(b)};base64,${b.toString('base64')}`;
    } catch (e) { log('cover download failed: ' + e.message); }
  }
  coverCache.set(key, data);
  return data;
}
function applyFallback(track) {
  if (track.fallbackTried || !(track.title || track.artist)) return;
  track.fallbackTried = true;
  fetchCover(track.title, track.artist).then(data => {
    if (lastTrack !== track) return;
    if (data) { track.cover = data; refreshArt(); setTrayCover(data); log('cover from online search'); if (player && !player.isDestroyed()) player.webContents.send('track', track); deskUI().forEach(w => w.webContents.send('track', track)); }
    else diag('找不到封面(系統沒提供,線上搜尋也沒有)');
  }).catch(e => log('fallback error: ' + e.message));
}
ipcMain.on('cover-failed', () => { if (lastTrack) applyFallback(lastTrack); });

function onLine(line) {
  gotOutput = true;
  let d; try { d = JSON.parse(line); } catch { return; }
  if (d.type === 'log') { log('ps: ' + d.msg); if (/failed|no thumbnail/.test(d.msg)) diag(String(d.msg).slice(0, 90)); return; }
  if (d.type === 'state') {
    const wasPlaying = !!(lastState && lastState.playing);
    lastState = d;
    if (d.dur > 0) { curDur = d.dur; repickLyrics(d.dur); }
    if (wall && !wall.isDestroyed()) wall.webContents.send('state', d);
    if (wasPlaying !== !!d.playing || d.none) updateWallpaper();
    if (player && !player.isDestroyed()) player.webContents.send('state', d);
    if (lyr && !lyr.isDestroyed()) lyr.webContents.send('state', d);
    deskUI().forEach(w => w.webContents.send('state', d));
    if (d.none) { setTrayCover(null); showLyrics(null); }
    return;
  }
  if (d.type === 'volume') { lastVol = d; deskUI().forEach(w => w.webContents.send('volume', d)); return; }
  if (d.type === 'fs') { onFs(d.q); return; }
  if (d.type === 'wins') { onWins(d); return; }
  if (d.type === 'cover') {   // the cover arrives a moment after the song itself
    if (!lastTrack || lastTrack.key !== d.key) return;
    let c = null;
    if (d.thumb) { try { const b = fs.readFileSync(d.thumb); c = `data:${mimeOf(b)};base64,${b.toString('base64')}`; } catch (e) { log('read thumb failed: ' + e.message); } }
    if (c) { lastTrack.cover = c; refreshArt(); setTrayCover(c); if (player && !player.isDestroyed()) player.webContents.send('track', lastTrack); deskUI().forEach(w => w.webContents.send('track', lastTrack)); }
    else if (!lastTrack.cover) applyFallback(lastTrack);
    return;
  }
  if (d.type !== 'track') return;
  log(`track: ${d.artist} - ${d.title} | thumb=${d.thumb ? 'yes' : 'NO'} | app=${d.app}`);
  if (tray && (d.title || d.artist)) tray.setToolTip(`${d.artist ? d.artist + ' - ' : ''}${d.title}`.slice(0, 120));
  let cover = null;
  if (d.thumb) {
    try {
      const b = fs.readFileSync(d.thumb);
      cover = `data:${mimeOf(b)};base64,${b.toString('base64')}`;
    } catch (e) { log('read thumb failed: ' + e.message); }
  }
  const t = lastTrack = { key: d.key, title: d.title, artist: d.artist, cover, app: d.app };
  if (player && !player.isDestroyed()) player.webContents.send('track', t);
  if (lyr && !lyr.isDestroyed()) lyr.webContents.send('track', t);
  deskUI().forEach(w => w.webContents.send('track', t));
  setTrayCover(cover);
  loadLyrics(t);
  loadWallpaper(t);
  if (d.pending) setTimeout(() => { if (lastTrack === t && !t.cover) applyFallback(t); }, 700);   // system cover did not come quickly: look it up online
  else if (!cover) applyFallback(t);
}
let expectedExit = false;
function startNowPlaying() {
  const logPs = path.join(os.tmpdir(), 'ibaila-ps.log');
  try { fs.rmSync(logPs, { force: true }); } catch {}
  try { fs.rmSync(cmdDir, { recursive: true, force: true }); fs.mkdirSync(cmdDir, { recursive: true }); } catch {}
  gotOutput = false; expectedExit = false;
  // 把變數塞進腳本開頭(下面再寫成暫存檔執行)
  const header = `$CmdDir='${cmdDir.replace(/'/g, "''")}'; $ParentPid=${process.pid};\n`;
  const src = header + fs.readFileSync(path.join(__dirname, 'nowplaying.ps1'), 'utf8');
  // script goes to a temp file with a UTF-8 BOM (PowerShell 5.1 needs it) - avoids the command-line length limit of -EncodedCommand
  const scriptFile = path.join(os.tmpdir(), 'ibaila-reader-' + process.pid + '.ps1');
  fs.writeFileSync(scriptFile, '\uFEFF' + src, 'utf8');
  ps = spawn(PS_EXE, ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-File', scriptFile], { windowsHide: true, stdio: ['ignore', 'pipe', 'pipe'] });
  const me = ps;
  syncDesktopOnly();
  let buf = '';
  ps.stdout.setEncoding('utf8');
  ps.stdout.on('data', c => {
    buf += c; let i;
    while ((i = buf.indexOf('\n')) >= 0) {
      const line = buf.slice(0, i).trim().replace(/^\uFEFF/, ''); buf = buf.slice(i + 1);
      if (line) onLine(line);
    }
  });
  ps.stderr.on('data', c => { const t = String(c).trim(); if (!t || /CLIXML/.test(t)) return; log('ps stderr: ' + t); diag('PowerShell: ' + t.replace(/\s+/g, ' ').slice(0, 90)); });
  ps.on('error', e => diag('無法啟動 PowerShell: ' + e.message));
  ps.on('exit', code => { if (!expectedExit) diag('讀取程式已停止 (code ' + code + ')'); });
  setTimeout(() => {
    if (me !== ps || gotOutput) return;
    let tail = ''; try { tail = fs.readFileSync(logPs, 'utf8').trim().split('\n').slice(-2).join(' | '); } catch {}
    diag(tail ? '有執行但沒收到輸出: ' + tail : 'PowerShell 沒有執行腳本');
  }, 6000);
  if (S.source !== 'auto') sendCmd('source:' + S.source);
  if (isLite()) sendCmd('rate:slow');
}
function restartReader() {
  expectedExit = true; try { ps && ps.kill(); } catch {}
  lastTrack = null; lastState = null;
  startNowPlaying();
}

function buildMenu() {
  if (!tray) return;
  tray.setContextMenu(Menu.buildFromTemplate([
    { label: T('開啟設定'), click: () => openSettings() },
    { type: 'separator' },
    { label: T('開啟燈光'), type: 'checkbox', checked: S.enabled, click: () => { S.enabled = !S.enabled; save(); } },
    { label: T('顯示桌面播放器'), type: 'checkbox', checked: S.player, click: () => { S.player = !S.player; save(); } },
    { type: 'separator' },
    { label: T('結束'), click: () => app.quit() }
  ]));
}

app.whenReady().then(() => {
  if (!I18N.LANGS.some(x => x[0] === S.lang)) S.lang = I18N.detect(app.getLocale());   // 第一次:先依系統語言預選,歡迎畫面可改
  I18N.setLang(S.lang);
  try { fs.writeFileSync(logFile(), ''); } catch {}
  log('start, acrylic=' + acrylic);
  session.defaultSession.setDisplayMediaRequestHandler((req, cb) => {
    desktopCapturer.getSources({ types: ['screen'] }).then(src => cb({ video: src[0], audio: 'loopback' }));
  });
  tray = new Tray(nativeImage.createFromPath(path.join(__dirname, 'icon-32.png')));
  tray.setToolTip('RhythZah');
  tray.on('click', () => openSettings());
  tray.on('double-click', () => openSettings());
  buildMenu();
  makeOverlays();
  makePlayer();
  makeDesk();
  makeLyrics();
  try {
    onBattery = powerMonitor.isOnBatteryPower();
    powerMonitor.on('on-battery', () => { onBattery = true; applyPower(); });
    powerMonitor.on('on-ac', () => { onBattery = false; applyPower(); });
  } catch (e) { log('power monitor unavailable: ' + e.message); }
  if (S.wall) makeWallpaper();
  startNowPlaying();
  applyPower();
  if (!S.onboarded) { S.welcomed = true; save(); setTimeout(openWelcome, 700); }   // 第一次開啟:跳出引導視窗(選軟體 + 開機自動啟動)
});
app.on('before-quit', () => { try { fs.rmSync(path.join(os.tmpdir(), 'ibaila-reader-' + process.pid + '.ps1'), { force: true }); } catch {} expectedExit = true; try { ps && ps.kill(); } catch {} try { fs.rmSync(cmdDir, { recursive: true, force: true }); } catch {} });
app.on('window-all-closed', e => e.preventDefault());
