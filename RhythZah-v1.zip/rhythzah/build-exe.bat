@echo off
chcp 65001 >nul
net session >nul 2>&1
if %errorlevel% neq 0 (
  echo 需要系統管理員權限,正在重新以系統管理員開啟...
  powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
  exit /b
)
cd /d "%~dp0"
set CSC_IDENTITY_AUTO_DISCOVERY=false
if exist "%LOCALAPPDATA%\electron-builder\Cache\winCodeSign" rmdir /s /q "%LOCALAPPDATA%\electron-builder\Cache\winCodeSign"
echo [1/2] 安裝套件(第一次會比較久)...
call npm install
if errorlevel 1 goto fail
echo [2/2] 打包安裝檔...
call npm run dist
if errorlevel 1 goto fail
echo.
echo 完成!安裝檔在 dist 資料夾: RhythZah-Setup-1.0.0.exe
start "" dist
pause
exit /b 0
:fail
echo 打包失敗,請把上面的錯誤訊息貼給我。
pause
