/* RhythZah i18n — 原文是繁體中文,其他語言對照: [en, zh-CN, ja, ko]
   - 主程式:  const I18N = require('./i18n'); I18N.t('開啟設定')
   - 視窗:    <script src="i18n.js"></script> 放在最前面,文字與 title/placeholder 會自動翻譯,切換語言即時生效 */
(function () {
  const LANGS = [['en', 'English'], ['zh-TW', '繁體中文'], ['zh-CN', '简体中文'], ['ja', '日本語'], ['ko', '한국어']];
  const IDX = { en: 0, 'zh-CN': 1, ja: 2, ko: 3 };
  const D = {
    // ---- 歡迎引導 ----
    '歡迎使用 RhythZah': ['Welcome to RhythZah', '欢迎使用 RhythZah', 'RhythZah へようこそ', 'RhythZah에 오신 것을 환영합니다'],
    '讓音樂點亮整個螢幕。': ['Let music light up your whole screen.', '让音乐点亮整个屏幕。', '音楽で画面全体を照らそう。', '음악으로 화면 전체를 밝혀 보세요.'],
    '只要兩個小問題:音樂軟體,和要不要開機自動啟動。': ['Just two quick questions: your music app, and whether to start with Windows.', '只有两个小问题:音乐软件,以及是否开机自动启动。', '質問は2つだけ:音楽アプリと、起動時に自動で開始するか。', '질문은 단 두 가지: 음악 앱과 부팅 시 자동 실행 여부.'],
    '開始設定': ['Get started', '开始设置', 'セットアップ開始', '설정 시작'],
    '第 1 步 / 共 2 步': ['Step 1 of 2', '第 1 步 / 共 2 步', 'ステップ 1 / 2', '1단계 / 2단계'],
    '第 2 步 / 共 2 步': ['Step 2 of 2', '第 2 步 / 共 2 步', 'ステップ 2 / 2', '2단계 / 2단계'],
    '你要連結哪個音樂軟體?': ['Which music app do you use?', '你要连接哪个音乐软件?', 'どの音楽アプリを使いますか?', '어떤 음악 앱을 사용하시나요?'],
    'RhythZah 會讀取它正在播放的歌,同步燈光、歌詞與桌布。': ['RhythZah reads what it is playing and syncs the lights, lyrics and wallpaper.', 'RhythZah 会读取它正在播放的歌曲,同步灯光、歌词与壁纸。', '再生中の曲を読み取り、ライト・歌詞・壁紙を同期します。', '재생 중인 곡을 읽어 조명, 가사, 배경화면을 동기화합니다.'],
    '自動偵測': ['Auto-detect', '自动检测', '自動検出', '자동 감지'],
    '誰在播就讀誰': ['Reads whichever is playing', '谁在播就读谁', '再生中のアプリを読み取り', '재생 중인 앱을 읽어요'],
    '桌面版 / 網頁版': ['Desktop / Web', '桌面版 / 网页版', 'デスクトップ / Web 版', '데스크톱 / 웹'],
    '瀏覽器播放': ['Plays in browser', '浏览器播放', 'ブラウザで再生', '브라우저에서 재생'],
    '推薦': ['Best', '推荐', 'おすすめ', '추천'],
    '執行中': ['Running', '运行中', '実行中', '실행 중'],
    '下一步': ['Next', '下一步', '次へ', '다음'],
    '← 上一步': ['← Back', '← 上一步', '← 戻る', '← 이전'],
    '略過': ['Skip', '跳过', 'スキップ', '건너뛰기'],
    '要在開機時自動啟動嗎?': ['Start automatically with Windows?', '要在开机时自动启动吗?', 'Windows 起動時に自動で開始しますか?', 'Windows 시작 시 자동으로 실행할까요?'],
    '啟動後會安靜待在右下角通知區,隨時點圖示就能開設定。': ['It stays quietly in the system tray — click the icon any time to open settings.', '启动后会安静地待在右下角通知区,随时点击图标即可打开设置。', '起動後は右下の通知領域に常駐します。アイコンをクリックすればいつでも設定を開けます。', '실행 후에는 오른쪽 아래 알림 영역에 조용히 머물며, 아이콘을 누르면 언제든 설정을 열 수 있어요.'],
    '好,開機自動啟動': ['Yes, start with Windows', '好,开机自动启动', 'はい、自動で起動', '네, 자동으로 실행'],
    '打開電腦,燈光和歌詞就已就緒。': ['Lights and lyrics are ready the moment you turn on your PC.', '打开电脑,灯光和歌词就已就绪。', 'PC を起動すれば、ライトも歌詞もすぐ使えます。', '컴퓨터를 켜면 조명과 가사가 바로 준비돼요.'],
    '不用,我自己開': ['No, I\'ll open it myself', '不用,我自己开', 'いいえ、自分で開きます', '아니요, 직접 열게요'],
    '需要時再從桌面捷徑手動啟動。': ['Launch it from the desktop shortcut when you need it.', '需要时再从桌面快捷方式手动启动。', '必要なときにデスクトップのショートカットから起動します。', '필요할 때 바탕화면 바로가기로 직접 실행하세요.'],
    '右下角通知區會出現 RhythZah 圖示': ['A RhythZah icon will appear in the system tray', '右下角通知区会出现 RhythZah 图标', '右下の通知領域に RhythZah のアイコンが表示されます', '오른쪽 아래 알림 영역에 RhythZah 아이콘이 나타납니다'],
    '之後可在設定 › 一般 隨時更改': ['Change it any time in Settings › General', '之后可在设置 › 常规 随时更改', '後から 設定 › 一般 でいつでも変更できます', '나중에 설정 › 일반에서 언제든 바꿀 수 있어요'],
    '完成': ['Done', '完成', '完了', '완료'],
    '全部設定好了': ['You\'re all set', '全部设置好了', 'セットアップ完了', '모든 설정이 끝났어요'],
    '接下來帶你到設定頁,還能繼續調整燈光、歌詞與桌布。': ['Next, the settings page — where you can fine-tune lights, lyrics and wallpaper.', '接下来带你到设置页,还可以继续调整灯光、歌词与壁纸。', '次は設定ページへ。ライト・歌詞・壁紙をさらに調整できます。', '다음은 설정 화면입니다. 조명, 가사, 배경화면을 더 세밀하게 조정할 수 있어요.'],
    '先播放一首歌,看看螢幕邊緣亮起來吧。': ['Play a song and watch the edges of your screen light up.', '先播放一首歌,看看屏幕边缘亮起来吧。', '曲を再生して、画面の縁が光る様子を見てみましょう。', '노래를 재생해서 화면 가장자리가 빛나는 모습을 확인해 보세요.'],
    '前往設定': ['Open settings', '前往设置', '設定へ', '설정으로 이동'],
    '音效與背景音樂': ['Sound effects & background music', '音效与背景音乐', '効果音とBGM', '효과음 및 배경음악'],
    '🚀 開機自動啟動': ['🚀 Start with Windows', '🚀 开机自动启动', '🚀 起動時に自動開始', '🚀 부팅 시 자동 실행'],
    '🖐 手動啟動': ['🖐 Manual start', '🖐 手动启动', '🖐 手動で起動', '🖐 수동 실행'],
    // ---- 設定:導覽 / 首頁 ----
    'RhythZah 設定': ['RhythZah Settings', 'RhythZah 设置', 'RhythZah 設定', 'RhythZah 설정'],
    '首頁': ['Home', '首页', 'ホーム', '홈'],
    '一般': ['General', '常规', '一般', '일반'],
    '邊緣燈光': ['Edge Lights', '边缘灯光', 'エッジライト', '가장자리 조명'],
    '歌詞': ['Lyrics', '歌词', '歌詞', '가사'],
    '桌面介面': ['Desktop UI', '桌面界面', 'デスクトップ UI', '데스크톱 UI'],
    '動態桌布': ['Live Wallpaper', '动态壁纸', 'ライブ壁紙', '라이브 배경화면'],
    '讓音樂點亮整個螢幕': ['Let music light up your whole screen', '让音乐点亮整个屏幕', '音楽で画面全体を照らそう', '음악으로 화면 전체를 밝혀 보세요'],
    '音樂來源': ['Music source', '音乐来源', '音楽ソース', '음악 소스'],
    '首次設定完成!你的選擇已經套用,下面可以繼續微調。': ['Setup complete! Your choices are applied — keep tweaking below.', '首次设置完成!你的选择已经生效,下面可以继续微调。', 'セットアップ完了!選択内容が反映されました。下でさらに調整できます。', '초기 설정 완료! 선택이 적용되었어요. 아래에서 더 조정할 수 있습니다.'],
    '快速開關': ['Quick toggles', '快速开关', 'クイック切替', '빠른 설정'],
    '同步歌詞': ['Synced lyrics', '同步歌词', '同期歌詞', '동기화 가사'],
    '桌面播放器': ['Desktop player', '桌面播放器', 'デスクトッププレイヤー', '데스크톱 플레이어'],
    '介面音效': ['UI sounds', '界面音效', 'UI サウンド', 'UI 효과음'],
    '背景音樂': ['Background music', '背景音乐', 'BGM', '배경음악'],
    '已開啟': ['On', '已开启', 'オン', '켜짐'],
    '已關閉': ['Off', '已关闭', 'オフ', '꺼짐'],
    '開機與音樂來源': ['Startup & music source', '开机与音乐来源', '起動と音楽ソース', '시작 및 음악 소스'],
    '所有設定': ['All settings', '所有设置', 'すべての設定', '모든 설정'],
    '重新執行首次設定引導': ['Run first-time setup again', '重新运行首次设置向导', '初回セットアップをもう一度実行', '초기 설정 다시 실행'],
    '重新選擇要連結的音樂軟體與開機自動啟動': ['Re-pick the music app to link and the startup option', '重新选择要连接的音乐软件与开机自动启动', '連携する音楽アプリと自動起動を選び直す', '연결할 음악 앱과 자동 실행 옵션을 다시 선택'],
    '重新選擇音樂軟體與開機自動啟動': ['Re-pick your music app and startup option', '重新选择音乐软件与开机自动启动', '音楽アプリと自動起動を選び直す', '음악 앱과 자동 실행 옵션을 다시 선택'],
    '要讀取哪個音樂軟體正在播放的歌': ['Which music app to read the playing song from', '要读取哪个音乐软件正在播放的歌曲', 'どの音楽アプリの再生曲を読み取るか', '재생 중인 곡을 읽어 올 음악 앱'],
    '是否在這個螢幕上顯示邊緣燈光': ['Show edge lights on this screen', '是否在这个屏幕上显示边缘灯光', 'この画面でエッジライトを表示する', '이 화면에 가장자리 조명 표시'],
    // ---- 設定:邊緣燈光 ----
    '顏色、粗細、節拍靈敏度、顯示的螢幕': ['Color, thickness, beat sensitivity, screens', '颜色、粗细、节拍灵敏度、显示的屏幕', '色・太さ・ビート感度・表示する画面', '색상, 굵기, 비트 감도, 표시할 화면'],
    '開啟邊緣燈光': ['Enable edge lights', '开启边缘灯光', 'エッジライトを有効にする', '가장자리 조명 켜기'],
    '螢幕四周的光會跟著音樂跳動': ['Light around your screen pulses with the music', '屏幕四周的光会跟着音乐跳动', '画面の周囲の光が音楽に合わせて動きます', '화면 가장자리의 빛이 음악에 맞춰 움직여요'],
    '光圈跟著歌曲風格變化': ['Lights follow the song\'s genre', '光圈跟着歌曲风格变化', '曲のジャンルに合わせてライトが変化', '곡 장르에 따라 조명 스타일 변경'],
    '嘻哈、搖滾、EDM…各有不同的燈光樣式;關掉就是單一經典樣式': ['Hip-hop, rock, EDM… each has its own light style; off uses one classic style', '嘻哈、摇滚、EDM…各有不同的灯光样式;关闭则使用单一经典样式', 'ヒップホップ・ロック・EDM など、ジャンルごとに違うスタイル。オフにするとクラシックスタイル1種類になります', '힙합, 록, EDM 등 장르마다 다른 조명 스타일. 끄면 하나의 클래식 스타일만 사용해요'],
    '顏色': ['Color', '颜色', '色', '색상'],
    '專輯封面取色': ['From album art', '取自专辑封面', 'アルバムアートから抽出', '앨범 아트에서 추출'],
    '彩虹流動': ['Rainbow flow', '彩虹流动', 'レインボー', '무지개 흐름'],
    '粉紅': ['Pink', '粉红', 'ピンク', '핑크'],
    '藍色': ['Blue', '蓝色', 'ブルー', '파랑'],
    '紫色': ['Purple', '紫色', 'パープル', '보라'],
    '綠色': ['Green', '绿色', 'グリーン', '초록'],
    '橘色': ['Orange', '橙色', 'オレンジ', '주황'],
    '白色': ['White', '白色', 'ホワイト', '흰색'],
    '光的粗細': ['Light thickness', '光的粗细', '光の太さ', '빛 굵기'],
    '細': ['Thin', '细', '細', '얇게'],
    '中': ['Medium', '中', '中', '보통'],
    '粗': ['Thick', '粗', '太', '굵게'],
    '節拍靈敏度': ['Beat sensitivity', '节拍灵敏度', 'ビート感度', '비트 감도'],
    '越高,光越容易跟著低音閃': ['Higher = lights react more to the bass', '越高,光越容易跟着低音闪', '高いほど低音に反応しやすくなります', '높을수록 저음에 더 잘 반응해요'],
    '低': ['Low', '低', '低', '낮음'],
    '高': ['High', '高', '高', '높음'],
    // ---- 設定:歌詞 ----
    '風格、特效強度、簡繁、時間微調': ['Style, effect intensity, Traditional/Simplified, timing', '风格、特效强度、简繁、时间微调', 'スタイル・エフェクト強度・簡体/繁体・タイミング調整', '스타일, 효과 강도, 간체/번체, 싱크 조정'],
    '顯示同步歌詞': ['Show synced lyrics', '显示同步歌词', '同期歌詞を表示', '동기화 가사 표시'],
    '歌詞風格': ['Lyric style', '歌词风格', '歌詞スタイル', '가사 스타일'],
    '「自動」會依歌曲曲風挑選': ['"Auto" picks a style based on the song\'s genre', '“自动”会根据歌曲曲风挑选', '「自動」は曲のジャンルに合わせて選びます', '"자동"은 곡 장르에 맞춰 선택해요'],
    '自動(依歌曲曲風)': ['Auto (by genre)', '自动(依歌曲曲风)', '自動(ジャンル別)', '자동 (장르별)'],
    '流行 Pop': ['Pop', '流行 Pop', 'ポップ Pop', '팝 Pop'],
    '偶像 K/J-Pop': ['Idol K/J-Pop', '偶像 K/J-Pop', 'アイドル K/J-Pop', '아이돌 K/J-Pop'],
    '嘻哈 Hip-Hop': ['Hip-Hop', '嘻哈 Hip-Hop', 'ヒップホップ Hip-Hop', '힙합 Hip-Hop'],
    '搖滾 Rock': ['Rock', '摇滚 Rock', 'ロック Rock', '록 Rock'],
    '電子 EDM': ['Electronic EDM', '电子 EDM', 'エレクトロ EDM', '일렉트로닉 EDM'],
    '爵士 / 藍調': ['Jazz / Blues', '爵士 / 蓝调', 'ジャズ / ブルース', '재즈 / 블루스'],
    '民謠 / 鄉村': ['Folk / Country', '民谣 / 乡村', 'フォーク / カントリー', '포크 / 컨트리'],
    '夢幻 / Chill': ['Dreamy / Chill', '梦幻 / Chill', 'ドリーミー / Chill', '몽환 / Chill'],
    '拉丁 / 雷鬼': ['Latin / Reggae', '拉丁 / 雷鬼', 'ラテン / レゲエ', '라틴 / 레게'],
    '抒情慢歌 Ballad': ['Ballad', '抒情慢歌 Ballad', 'バラード Ballad', '발라드 Ballad'],
    '復古 / City Pop': ['Retro / City Pop', '复古 / City Pop', 'レトロ / シティポップ', '레트로 / 시티팝'],
    '電影 / 古典': ['Cinematic / Classical', '电影 / 古典', 'シネマ / クラシック', '영화 / 클래식'],
    '玻璃滾筒': ['Glass roller', '玻璃滚筒', 'ガラスローラー', '글래스 롤러'],
    '歌詞特效強度': ['Lyric effect intensity', '歌词特效强度', '歌詞エフェクト強度', '가사 효과 강도'],
    '柔和': ['Soft', '柔和', 'やさしい', '부드럽게'],
    '標準': ['Standard', '标准', '標準', '표준'],
    '強烈': ['Intense', '强烈', '強め', '강하게'],
    '歌詞簡繁': ['Lyrics script', '歌词简繁', '歌詞の簡体/繁体', '가사 간체/번체'],
    '繁體': ['Traditional', '繁体', '繁体字', '번체'],
    '簡體': ['Simplified', '简体', '簡体字', '간체'],
    '不轉換': ['No conversion', '不转换', '変換しない', '변환 안 함'],
    '歌詞時間微調': ['Lyric timing', '歌词时间微调', '歌詞タイミング調整', '가사 싱크 조정'],
    '覺得歌詞太早或太晚出現時調整': ['Adjust if lyrics appear too early or too late', '觉得歌词出现太早或太晚时调整', '歌詞が早すぎる・遅すぎるときに調整します', '가사가 너무 빠르거나 느리게 나올 때 조정하세요'],
    '歌詞只顯示在桌面': ['Show lyrics on desktop only', '歌词只显示在桌面', '歌詞をデスクトップのみに表示', '바탕화면에서만 가사 표시'],
    '有視窗蓋到歌詞區域時先藏起來': ['Hide lyrics while a window covers them', '有窗口盖住歌词区域时先隐藏', 'ウィンドウが重なっている間は歌詞を隠します', '창이 가사 영역을 덮으면 가사를 숨겨요'],
    '重新抓取歌詞': ['Re-fetch lyrics', '重新获取歌词', '歌詞を再取得', '가사 다시 가져오기'],
    '目前這首歌的歌詞不對或沒出來時使用': ['Use when lyrics are wrong or missing for this song', '当前歌曲的歌词不对或没出现时使用', 'この曲の歌詞が違う・表示されないときに使います', '이 곡의 가사가 틀리거나 나오지 않을 때 사용하세요'],
    '重新抓取': ['Re-fetch', '重新获取', '再取得', '다시 가져오기'],
    // ---- 設定:桌面介面 / 桌布 ----
    '桌面播放器、完整介面、播放來源': ['Desktop player, full interface, playback source', '桌面播放器、完整界面、播放来源', 'デスクトッププレイヤー・フルUI・再生ソース', '데스크톱 플레이어, 전체 화면 UI, 재생 소스'],
    '顯示桌面播放器': ['Show desktop player', '显示桌面播放器', 'デスクトッププレイヤーを表示', '데스크톱 플레이어 표시'],
    '關掉後只剩邊緣燈光與歌詞': ['When off, only edge lights and lyrics remain', '关闭后只剩边缘灯光与歌词', 'オフにするとエッジライトと歌詞のみになります', '끄면 가장자리 조명과 가사만 남아요'],
    '桌面完整介面': ['Full desktop interface', '桌面完整界面', 'デスクトップのフルUI', '데스크톱 전체 UI'],
    '正在播放資訊、搜尋列、歌單、Cover Flow;關掉會改用小型浮動播放器': ['Now playing, search bar, playlists, Cover Flow; when off, a small floating player is used', '正在播放信息、搜索栏、歌单、Cover Flow;关闭后改用小型悬浮播放器', '再生中の情報・検索バー・プレイリスト・Cover Flow。オフにすると小型フローティングプレイヤーになります', '재생 정보, 검색창, 플레이리스트, Cover Flow. 끄면 작은 플로팅 플레이어를 사용해요'],
    '播放來源': ['Playback source', '播放来源', '再生ソース', '재생 소스'],
    '要讀取哪個程式正在播的歌': ['Which app to read the playing song from', '要读取哪个程序正在播放的歌曲', 'どのアプリの再生曲を読み取るか', '재생 중인 곡을 읽어 올 앱'],
    '自動(目前播放的)': ['Auto (whatever is playing)', '自动(当前播放的)', '自動(再生中のもの)', '자동 (재생 중인 앱)'],
    'MV / 動態封面桌布、自訂影片資料夾': ['MV / animated cover wallpaper, custom video folder', 'MV / 动态封面壁纸、自定义视频文件夹', 'MV・動くカバー壁紙・カスタム動画フォルダ', 'MV / 움직이는 커버 배경화면, 사용자 영상 폴더'],
    '開啟動態桌布': ['Enable live wallpaper', '开启动态壁纸', 'ライブ壁紙を有効にする', '라이브 배경화면 켜기'],
    '播放中的歌曲 MV / 動態封面會變成桌面背景;暫停就收起來': ['The playing song\'s MV / animated cover becomes your desktop background; it hides when paused', '播放中歌曲的 MV / 动态封面会变成桌面背景;暂停时收起', '再生中の曲の MV や動くカバーがデスクトップ背景になります。一時停止すると非表示になります', '재생 중인 곡의 MV / 움직이는 커버가 바탕화면이 되고, 일시정지하면 사라져요'],
    '沒有動態影片時用專輯封面當桌布': ['Use album art when no video is available', '没有动态视频时用专辑封面当壁纸', '動画がない場合はアルバムアートを壁紙にする', '영상이 없으면 앨범 아트를 배경으로 사용'],
    '用電池時也播放': ['Play on battery too', '使用电池时也播放', 'バッテリー駆動時も再生', '배터리 사용 중에도 재생'],
    '預設用電池時為了省電不播桌布': ['By default the wallpaper is paused on battery to save power', '默认使用电池时为省电不播放壁纸', '既定ではバッテリー駆動時は省電力のため壁紙を再生しません', '기본적으로 배터리 사용 시 절전을 위해 배경화면을 재생하지 않아요'],
    '自訂影片資料夾': ['Custom video folder', '自定义视频文件夹', 'カスタム動画フォルダ', '사용자 영상 폴더'],
    '放入「歌手 - 歌名.mp4」,整支 MV 會跟著歌曲進度同步(可放 4K)': ['Drop in "Artist - Title.mp4" and the whole MV syncs with the song (4K supported)', '放入“歌手 - 歌名.mp4”,整支 MV 会跟随歌曲进度同步(支持 4K)', '「アーティスト - 曲名.mp4」を入れると、MV 全体が曲の進行に同期します(4K 対応)', '"가수 - 제목.mp4"를 넣으면 MV 전체가 곡 진행에 맞춰 재생돼요 (4K 지원)'],
    '開啟資料夾': ['Open folder', '打开文件夹', 'フォルダを開く', '폴더 열기'],
    '重新連接桌布': ['Reconnect wallpaper', '重新连接壁纸', '壁紙を再接続', '배경화면 다시 연결'],
    '桌布沒有出現在桌面時試試看': ['Try this if the wallpaper doesn\'t show on your desktop', '壁纸没有出现在桌面时试试看', '壁紙がデスクトップに表示されないときに試してください', '배경화면이 바탕화면에 나타나지 않을 때 시도해 보세요'],
    '重新連接': ['Reconnect', '重新连接', '再接続', '다시 연결'],
    // ---- 設定:一般 ----
    '省電、全螢幕、開機啟動、紀錄檔': ['Power saving, fullscreen, startup, log file', '省电、全屏、开机启动、日志文件', '省電力・フルスクリーン・自動起動・ログ', '절전, 전체 화면, 자동 실행, 로그 파일'],
    '語言': ['Language', '语言', '言語', '언어'],
    '介面顯示語言': ['Display language of the app', '界面显示语言', 'アプリの表示言語', '앱 표시 언어'],
    '省電模式': ['Power saving', '省电模式', '省電力モード', '절전 모드'],
    '省電時會降低更新率': ['Lowers the refresh rate when saving power', '省电时会降低刷新率', '省電力時は更新頻度を下げます', '절전 시 갱신 빈도를 낮춰요'],
    '自動': ['Auto', '自动', '自動', '자동'],
    '一律省電': ['Always', '始终省电', '常にオン', '항상 사용'],
    '關閉': ['Off', '关闭', 'オフ', '끄기'],
    '全螢幕時自動隱藏': ['Hide automatically in fullscreen', '全屏时自动隐藏', 'フルスクリーン時に自動で隠す', '전체 화면에서 자동 숨김'],
    '玩遊戲或看全螢幕影片時暫時收起所有燈光與介面': ['Temporarily hides all lights and UI while gaming or watching fullscreen video', '玩游戏或观看全屏视频时暂时收起所有灯光与界面', 'ゲームやフルスクリーン動画の視聴中は、ライトとUIを一時的に隠します', '게임이나 전체 화면 영상 시청 중에는 모든 조명과 UI를 잠시 숨겨요'],
    '滑過、點擊、切換時的玻璃質感音效': ['Glassy sounds on hover, click and switch', '滑过、点击、切换时的玻璃质感音效', 'ホバー・クリック・切替時のガラス質な効果音', '마우스를 올리거나 클릭·전환할 때 나는 유리 질감 효과음'],
    '開著設定或歡迎視窗時播放的氛圍音樂;視窗不在前景時會自動淡出': ['Ambient music while Settings or Welcome is open; fades out when the window is in the background', '打开设置或欢迎窗口时播放的氛围音乐;窗口不在前台时会自动淡出', '設定やウェルカム画面を開いている間に流れるBGM。ウィンドウが背面にあると自動でフェードアウトします', '설정 또는 환영 창이 열려 있을 때 재생되는 분위기 음악. 창이 뒤로 가면 자동으로 사라져요'],
    '音效與背景音樂音量': ['Sound effects & music volume', '音效与背景音乐音量', '効果音とBGMの音量', '효과음 및 배경음악 볼륨'],
    '開機自動啟動': ['Start with Windows', '开机自动启动', 'Windows 起動時に自動開始', '부팅 시 자동 실행'],
    '打開電腦時自動啟動,安靜待在右下角通知區': ['Starts when you turn on your PC and stays quietly in the system tray', '打开电脑时自动启动,安静地待在右下角通知区', 'PC の起動時に自動で開始し、右下の通知領域に常駐します', '컴퓨터를 켜면 자동으로 실행되어 오른쪽 아래 알림 영역에 조용히 머물러요'],
    '開啟引導': ['Open setup', '打开向导', 'セットアップを開く', '설정 열기'],
    '開啟紀錄檔': ['Open log file', '打开日志文件', 'ログファイルを開く', '로그 파일 열기'],
    '除錯用': ['For debugging', '调试用', 'デバッグ用', '디버그용'],
    '開啟': ['Open', '打开', '開く', '열기'],
    '重新啟動讀取程式': ['Restart the reader', '重新启动读取程序', 'リーダーを再起動', '리더 다시 시작'],
    '抓不到正在播放的歌時使用': ['Use when the playing song can\'t be detected', '读取不到正在播放的歌曲时使用', '再生中の曲が取得できないときに使います', '재생 중인 곡을 가져오지 못할 때 사용하세요'],
    '重新啟動': ['Restart', '重新启动', '再起動', '다시 시작'],
    '結束 RhythZah': ['Quit RhythZah', '退出 RhythZah', 'RhythZah を終了', 'RhythZah 종료'],
    '完全關閉程式(關閉這個視窗不會結束程式,它會留在右下角通知區)': ['Quit completely (closing this window doesn\'t quit — the app stays in the system tray)', '完全关闭程序(关闭此窗口不会退出程序,它会留在右下角通知区)', 'アプリを完全に終了します(このウィンドウを閉じても終了せず、通知領域に残ります)', '앱을 완전히 종료합니다 (이 창을 닫아도 종료되지 않고 알림 영역에 남아요)'],
    '結束程式': ['Quit app', '退出程序', 'アプリを終了', '앱 종료'],
    // ---- 桌面介面 / 播放器 ----
    '沒有正在播放的歌曲': ['Nothing playing', '没有正在播放的歌曲', '再生中の曲はありません', '재생 중인 곡이 없어요'],
    '開始播放音樂吧': ['Start playing some music', '开始播放音乐吧', '音楽を再生してみましょう', '음악을 재생해 보세요'],
    '可以點封面下方的標籤換來源': ['Tap the label under the cover to switch source', '可以点封面下方的标签切换来源', 'カバー下のラベルをクリックしてソースを切り替えられます', '커버 아래 라벨을 눌러 소스를 바꿀 수 있어요'],
    '未知歌曲': ['Unknown song', '未知歌曲', '不明な曲', '알 수 없는 곡'],
    '自動 ▾': ['Auto ▾', '自动 ▾', '自動 ▾', '자동 ▾'],
    '搜尋歌曲或歌手': ['Search songs or artists', '搜索歌曲或歌手', '曲またはアーティストを検索', '곡 또는 가수 검색'],
    '找不到結果': ['No results', '找不到结果', '結果が見つかりません', '결과가 없어요'],
    '上一首': ['Previous', '上一首', '前の曲', '이전 곡'],
    '下一首': ['Next', '下一首', '次の曲', '다음 곡'],
    '播放 / 暫停': ['Play / Pause', '播放 / 暂停', '再生 / 一時停止', '재생 / 일시정지'],
    'MV 桌布': ['MV wallpaper', 'MV 壁纸', 'MV 壁紙', 'MV 배경화면'],
    '音量': ['Volume', '音量', '音量', '볼륨'],
    '音量(滾輪也可以調)': ['Volume (scroll wheel works too)', '音量(滚轮也可以调节)', '音量(マウスホイールでも調整できます)', '볼륨 (마우스 휠로도 조절 가능)'],
    '靜音': ['Mute', '静音', 'ミュート', '음소거'],
    // ---- 托盤選單 ----
    '開啟設定': ['Open settings', '打开设置', '設定を開く', '설정 열기'],
    '開啟燈光': ['Enable lights', '开启灯光', 'ライトを有効にする', '조명 켜기'],
    '結束': ['Quit', '退出', '終了', '종료']
  };
  // 帶變數的句子: {0} {1} 會被原樣帶入(內容自己再翻譯一次)
  const PAT = [
    ['提早 {0} 秒', ['{0} s earlier', '提前 {0} 秒', '{0} 秒早める', '{0}초 빠르게']],
    ['延後 {0} 秒', ['{0} s later', '延后 {0} 秒', '{0} 秒遅らせる', '{0}초 늦게']],
    ['沒有來自 {0} 的播放', ['Nothing playing from {0}', '没有来自 {0} 的播放', '{0} からの再生はありません', '{0}에서 재생 중인 곡이 없어요']],
    ['螢幕 {0}(主要)  {1}', ['Screen {0} (primary)  {1}', '屏幕 {0}(主屏)  {1}', 'ディスプレイ {0}(メイン)  {1}', '화면 {0} (주 화면)  {1}']],
    ['螢幕 {0}  {1}', ['Screen {0}  {1}', '屏幕 {0}  {1}', 'ディスプレイ {0}  {1}', '화면 {0}  {1}']],
    ['🎧 {0}', ['🎧 {0}', '🎧 {0}', '🎧 {0}', '🎧 {0}']]
  ].map(([k, v]) => {
    const re = new RegExp('^' + k.replace(/[.*+?^$()|[\]\\]/g, '\\$&').replace(/\{\d\}/g, '(.+?)') + '$');
    return [re, v];
  });

  let cur = 'zh-TW';
  const norm = l => (LANGS.some(x => x[0] === l) ? l : 'en');
  function detect(loc) {
    loc = String(loc || '').toLowerCase();
    if (/^zh[-_](tw|hk|mo|hant)/.test(loc)) return 'zh-TW';
    if (loc.startsWith('zh')) return 'zh-CN';
    if (loc.startsWith('ja')) return 'ja';
    if (loc.startsWith('ko')) return 'ko';
    return 'en';
  }
  function t(s, lang) {
    lang = lang || cur;
    if (typeof s !== 'string' || lang === 'zh-TW') return s;
    const k = s.trim(); if (!k) return s;
    const i = IDX[lang]; let r = null;
    const e = D[k];
    if (e) r = e[i];
    else for (const [re, v] of PAT) {
      const m = k.match(re);
      if (m) { let n = 0; r = v[i].replace(/\{(\d)\}/g, (_, d) => t(m[+d + 1], lang)); break; }
    }
    return r == null ? s : s.replace(k, () => r);
  }

  /* ---- 視窗端:自動翻譯 DOM(文字節點 + title/placeholder/aria-label),語言切換即時生效 ---- */
  const ATTRS = ['title', 'placeholder', 'aria-label'];
  const TXT = new WeakMap(), ATT = new WeakMap();
  const skip = n => { const p = n.nodeType === 3 ? n.parentNode : n; return !p || !p.closest || p.closest('[data-no-i18n],script,style,textarea'); };
  function doText(n) {
    if (skip(n)) return;
    const o = TXT.get(n), now = n.data, zh = o && o.out === now ? o.zh : now, out = t(zh);
    TXT.set(n, { zh, out });
    if (out !== now) n.data = out;
  }
  function doAttr(el, a) {
    if (!el.hasAttribute(a) || skip(el)) return;
    let m = ATT.get(el); if (!m) ATT.set(el, m = {});
    const o = m[a], now = el.getAttribute(a), zh = o && o.out === now ? o.zh : now, out = t(zh);
    m[a] = { zh, out };
    if (out !== now) el.setAttribute(a, out);
  }
  function walk(root) {
    if (!root) return;
    if (root.nodeType === 3) return doText(root);
    if (root.nodeType !== 1 && root.nodeType !== 9 && root.nodeType !== 11) return;
    if (root.nodeType === 1) ATTRS.forEach(a => doAttr(root, a));
    const w = document.createTreeWalker(root, 5);   // 1 | 4 = elements + text
    for (let n = w.nextNode(); n; n = w.nextNode()) { if (n.nodeType === 3) doText(n); else ATTRS.forEach(a => doAttr(n, a)); }
  }
  function mount() {
    walk(document.documentElement);
    new MutationObserver(list => {
      for (const m of list) {
        if (m.type === 'characterData') doText(m.target);
        else if (m.type === 'attributes') doAttr(m.target, m.attributeName);
        else m.addedNodes.forEach(walk);
      }
    }).observe(document.documentElement, { subtree: true, childList: true, characterData: true, attributes: true, attributeFilter: ATTRS });
  }
  function setLang(l) {
    l = norm(l); if (l === cur) return;
    cur = l;
    if (typeof document !== 'undefined' && document.documentElement) { document.documentElement.lang = l; walk(document.documentElement); }
  }

  const I18N = { LANGS, t, detect, setLang, get lang() { return cur; } };
  if (typeof window !== 'undefined' && typeof document !== 'undefined') {
    try {
      const { ipcRenderer } = require('electron');
      cur = norm(ipcRenderer.sendSync('lang:get'));
      ipcRenderer.on('lang', (_, l) => setLang(l));
    } catch {}
    document.documentElement.lang = cur;
    mount();
    window.I18N = I18N;
  }
  if (typeof module !== 'undefined') module.exports = I18N;
})();
