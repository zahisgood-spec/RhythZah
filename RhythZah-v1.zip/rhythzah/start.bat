@echo off
cd /d %~dp0
if not exist node_modules\hls.js call npm install
call npm start
