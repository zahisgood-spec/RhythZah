// 從封面取出三個主色(桌面播放器與精簡播放器共用)
function paletteFrom(img) {
  const c = document.createElement('canvas'); c.width = c.height = 32;
  const x = c.getContext('2d', { willReadFrequently: true });
  x.drawImage(img, 0, 0, 32, 32);
  const px = x.getImageData(0, 0, 32, 32).data;
  const bins = Array.from({ length: 12 }, () => ({ w: 0, h: 0, s: 0 }));
  let total = 0; const n = px.length / 4;
  for (let i = 0; i < px.length; i += 4) {
    if (px[i + 3] < 128) continue;
    const [h, s, l] = rgb2hsl(px[i], px[i + 1], px[i + 2]);
    const w = s * Math.max(0, 1 - Math.abs(l - 0.5) * 1.8);
    const b = bins[Math.min(11, Math.floor(h / 30))];
    b.w += w; b.h += h * w; b.s += s * w; total += w;
  }
  if (total / n < 0.06) return [[235, 235, 245], [170, 180, 210], [255, 255, 255]];
  const top = bins.filter(b => b.w > 0).sort((a, b) => b.w - a.w).filter((b, i, a) => b.w >= a[0].w * 0.25).slice(0, 3);
  const cols = top.map(b => hsl2rgb(b.h / b.w, Math.max(0.7, Math.min(1, b.s / b.w + 0.15)), 0.58));
  while (cols.length < 3) { const h = (top[0].h / top[0].w + (cols.length === 1 ? 28 : -28) + 360) % 360; cols.push(hsl2rgb(h, 0.8, 0.6)); }
  return cols;
}
function rgb2hsl(r, g, b) {
  r /= 255; g /= 255; b /= 255;
  const mx = Math.max(r, g, b), mn = Math.min(r, g, b), l = (mx + mn) / 2, d = mx - mn;
  let h = 0, s = 0;
  if (d) { s = d / (1 - Math.abs(2 * l - 1)); if (mx === r) h = ((g - b) / d) % 6; else if (mx === g) h = (b - r) / d + 2; else h = (r - g) / d + 4; h *= 60; if (h < 0) h += 360; }
  return [h, s, l];
}
function hsl2rgb(h, s, l) {
  const k = n => (n + h / 30) % 12, a = s * Math.min(l, 1 - l);
  const f = n => l - a * Math.max(-1, Math.min(k(n) - 3, 9 - k(n), 1));
  return [f(0), f(8), f(4)].map(v => Math.round(v * 255));
}


module.exports = paletteFrom;
